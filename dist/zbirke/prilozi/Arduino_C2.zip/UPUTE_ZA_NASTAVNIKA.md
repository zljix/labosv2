# Pripremljene usluge za cjelinu 2 — v12

Učenici prve tri cjeline ne pišu poslužiteljski kod. Nastavnik priprema jednu
lokalnu uslugu, a svaka grupa dobiva mrežne postavke i jedinstveni ID uređaja.
Python 3.10 ili noviji potreban je samo računalu. Na Windowsu se može koristiti
`py -3`, na drugim sustavima `python3`. U naredbama ispod `python` znači tu
lokalno instaliranu inačicu. Službeni Python: https://www.python.org/downloads/.

Sve naredbe izvodite u mapi **Arduino_C2**. ESP32 i računalo moraju biti na mreži
koja dopušta međusobni promet. Koristite LAN IPv4 adresu računala (na Windowsu
prikaz `ipconfig`), a ne 127.0.0.1 u postavkama ESP32. Ako treba, dopustite
potreban ulazni port samo u odobrenom privatnom nastavnom mrežnom profilu.

## HTTP: V2.1–V2.3

Pokrenite:

```text
python http_posluzitelj.py
```

Nisu potrebne dodatne Python biblioteke. Otvorite `http://127.0.0.1:8080/` na
poslužiteljskom računalu; ostala računala otvaraju njegovu LAN adresu na portu
8080. Konzola pri svakom pokretanju ispisuje novi **ključ za upravljanje**.
Polje za ključ u pregledniku ne pohranjuje ga trajno. Bez njega je dopušten
prikaz stanja; zahtjev za upravljanje dobiva HTTP 403. Podijelite ga operatorima.

Učenik u odjeljku POSTAVKE svoje 01_HTTP.ino datoteke upisuje `WIFI_SSID`,
`WIFI_LOZINKA`, dodijeljeni `UREDAJ_ID` i `HTTP_POSLUZITELJ`, primjerice
`"http://192.168.1.10:8080"`. Zatim postavlja `MREZA_OMOGUCENA=true`,
prevodi i učitava skicu. Adresa je primjer; koristi se stvarna LAN adresa.
Grupa u08 upisuje `UREDAJ_ID="u08"`. Serijski monitor samo ispisuje stanje.
Pričekajte `app_online:true`, odaberite uređaj u pregledniku i unesite ključ.

| Radnja | Očekivani dokaz |
|---|---|
| OPEN, CLOSE ili AUTO | prvo zahtjev u redu; zatim ACK uređaja s istim cmd_id |
| Ponovi poruku odmah nakon ACK | uređaj ne izvodi isto cmd_id ponovno; ako čekate predugo može prvo isteći izazov |
| Istek 6,5 s | odlazi izvorna poruka s već isteklim izazovom; nema prihvaćanja |
| Pogrešna sesija/uređaj/radnja | uređaj odbija poruku uz razlog |
| Pauza razmjene | broker nije relevantan; heartbeat HTTP aplikacije prestaje, uređaj prelazi u lokalni AUTO |
| Nastavi | nova aktualna razmjena; nema ponavljanja prethodne ručne naredbe |

HTTP ugovor: ESP32 šalje `POST /api/state` i čita
`GET /api/command?device=u07&session=...`. Preglednik čita `GET /ui/state`,
a upravlja pomoću `POST /ui/action` uz Bearer ključ. HTML datoteka mora ostati
uz Python skriptu. Za prekid usluge upotrijebite Ctrl+C.

Nadzorna ploča odvojeno pokazuje dob posljednje HTTP razmjene, dob primitka
posljednjeg različitog sample_seq u aktualnoj boot/sesiji i sample_age_ms koji uređaj
računa za svoje posljednje valjano očitanje. Ponovljeni isti seq osvježava samo
razmjenu, a ne vrijeme primitka novoga uzorka. Izvor podataka, valjanost i dob
moraju se čitati zajedno; dolazak poruke sam po sebi ne potvrđuje novo mjerenje.

Ključ štiti operatorski HTTP endpoint od zahtjeva bez ključa, ali ovo nije
potpuna sigurnosna arhitektura. Telemetrijski ESP endpoint nema provjeru
identiteta; HTTP nije šifriran, a sesijski izazov nije potpis. Koristite
izdvojeni pouzdani nastavni LAN i laboratorijske podatke. Servis nije za internet.

## MQTT: V2.3–V2.6 i V2.S

Broker i aplikacija dva su zasebna procesa. Instalirajte Eclipse Mosquitto sa
službene stranice https://mosquitto.org/download/. Koristite njegov CLI u PATH-u
ili cijeli put do izvršne datoteke. Za nastavnu konfiguraciju koja je priložena
morate najprije stvoriti datoteku lozinki; lozinke nisu uključene u paket.

```text
mosquitto_passwd -c passwd u07
mosquitto_passwd passwd nastavnik
mosquitto_passwd passwd promatrac
mosquitto -c mosquitto_nastava.conf -v
```

Svaka naredba `mosquitto_passwd` interaktivno traži novu laboratorijsku lozinku.
**Opcija -c koristi se samo prvi put:** ponovno bi stvorila datoteku i uklonila
prethodne korisnike. Držite ovu konzolu brokera otvorenom. Ako instalacija već
ima servis koji sluša port1883, nastavnik najprije zaustavlja taj vlastiti
servis ili odabire drugi slobodan port u konfiguraciji i u svim klijentima.

Priloženi ACL dopušta korisniku u07 pisanje `iot/u07/state` i `iot/u07/ack`,
te čitanje `iot/u07/command`. Korisnik nastavnik čita stanja i potvrde svih
grupa i objavljuje njihove naredbe. Korisnik promatrac smije samo čitati stanja
i potvrde. Za nove grupe nastavnik dodaje korisnika u datoteku lozinki i isti
blok ACL-a s njihovim ID-em pa ponovno pokreće broker. To je priprema
konfiguracije, a ne zadatak programiranja za učenika.

U drugoj konzoli, također u mapi Arduino_C2:

```text
python -m pip install -r requirements.txt
python mqtt_upravljanje.py --host 127.0.0.1 --device u07 --user nastavnik
```

Ako je aplikacija na drugom računalu, koristite LAN adresu brokera. Upis lozinke
je skriven; ona se ne stavlja u naredbeni redak ni paket. Za više uređaja
pokrenite po jednu konzolu aplikacije s različitim `--device`. Svaka aplikacija
automatski odgovara na nove izazove svojega uređaja.

Učenik u odjeljku POSTAVKE svoje MQTT .ino datoteke upisuje `WIFI_SSID`, `WIFI_LOZINKA`,
`UREDAJ_ID`, `MQTT_POSLUZITELJ`, `MQTT_PORT`, `MQTT_KORISNIK` i
`MQTT_LOZINKA`. Za MQTT adresu piše samo naziv/IP, bez `http://`.
Postavlja `MREZA_OMOGUCENA=true`, prevodi i učitava skicu. Postavke
ostaju nakon reseta; serijski monitor nije ulazno sučelje.

Učenik otvara http://127.0.0.1:8081/ na računalu svoje aplikacije. Za više
aplikacija na jednom računalu zadajte različite --http-port vrijednosti.
Za pristup s učeničkog računala nastavnik može zadati --http-host LAN_IP.
Prikaz odabrane probne oznake bez uređaja ne mijenja ID pločice.

Tipke: OPEN, CLOSE, AUTO, Ponovi istu naredbu, Nepoznata radnja,
Pošalji nakon isteka roka, Pauziraj nadzor i Obnovi nadzor.
Naredbu uvijek povežite s odgovarajućim cmd_id i ACK-om.
Nakon potvrđenog ručnog cilja pauzirajte nadzor više od 6 s: OFFLINE/AUTO
uz nova lokalna mjerenja. Obnova daje ONLINE/AUTO bez stare naredbe.
Broker, Wi-Fi i program pločice ostaju uključeni. Stara naredba šalje se
nakon 6,5 s, uz rok 6 s. Za nastavničku konzolu dodajte --cli; učenik koristi
preglednik. V2.S koristi 01_MQTT i istu MQTT aplikaciju.

Objave su QoS0, retain=false, klijenti koriste čistu sesiju. Paho klijent odbija
primljene retained state/ack poruke. PubSubClient na ESP32 ne izlaže RETAIN
zastavicu: on svježinu provjerava tokenima, izazovom, rokom i brojačem naredbi.
Ne prikazujte to kao izravno prepoznavanje svakog retained paketa u ESP biblioteci.

MQTT/TCP na portu1883 ovdje nije šifriran, uključujući vjerodajnice. ACL ograničuje
teme, ali ne zamjenjuje TLS. Koristite isključivo izdvojeni pouzdani LAN i
laboratorijske lozinke. Ne objavljujte ovaj broker na internetu.

## Prije sata i nakon pokusa

Pokrenite po jedan uređaj, potvrdite senzorski podatak, pa tek onda širite pokus
na grupe. Programski cilj nije izmjeren položaj serva. Pokus granica najprije
izvodite s `SERVO_OMOGUCEN=false`, `KOREKCIJA_C=0.0f` i
`POKUS=1` na vrhu .ino datoteke. Prije stvarnog mjerenja vratite
`POKUS=0` i odobrenu korekciju te ponovno učitajte skicu.
`SERVO_OMOGUCEN=true` dopušten je tek nakon upisa odobrenih granica i položaja
u µs. Prije promjene spoja odspojite USB i izvor serva. Ako spremljeni program
nije poznat, nastavnik uz oba izvora odspojena odvaja signal serva, uz USB
učitava i potvrđuje onemogućeni program, pa bez napajanja vraća pregledani spoj.
Dok je izlaz još onemogućen, uključite odobreni izvor serva; tek uz pravilno
napajan servo učitajte omogućenu inačicu. Prijenos i reset mogu izazvati gibanje.
Prije uključenja učenik pokazuje način hitnog prekida na potvrđenoj kartici.
Pri redovnom završetku dok je servo još napajan učitajte onemogućenu inačicu
i potvrdite prestanak impulsa, zatim isključite izvor serva pa USB. Pri opasnosti
hitni prekid ima prednost pred prijenosom. Pri prekidu veze
lokalni AUTO koristi aktualnu valjanu temperaturu: na 29 °C cilj ostaje OPEN;
nevaljano mjerenje ima prednost i daje CLOSED.

Pri ponovnom pokretanju servisa red čekanja je prazan. Brojač se usklađuje s
`last_cmd_id` iz svježega stanja ESP32. Promjena sesije odbacuje prethodne poruke.
Te mjere sprječavaju slučajno ponavljanje pokusa; ne pružaju kriptografsku
provjeru izvora naredbe. Na kraju zaustavite usluge, odspojite napajanja i
sačuvajte mjerne zapise bez lozinki i operatorskog ključa.

Službena dokumentacija:
- https://eclipse.dev/paho/files/paho.mqtt.python/html/client.html
- https://mosquitto.org/man/mosquitto-conf-5.html
- https://mosquitto.org/man/mosquitto_passwd-1.html
