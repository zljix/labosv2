#!/usr/bin/env python3
"""Gotov nastavnički MQTT klijent za P14; Python 3.10+, paho-mqtt 2.1.0."""
import argparse
import getpass
import json
import secrets
import threading
import time
from collections import deque
from urllib.parse import urlparse, parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    import paho.mqtt.client as mqtt
except ImportError:
    raise SystemExit('Instaliraj ovisnost: python -m pip install -r requirements.txt')


class Controller:
    def __init__(self, client, device, emit=print):
        self.client, self.device, self.emit = client, device, emit
        self.lock = threading.RLock()
        self.state = None
        self.received = 0.0
        self.counter = 0
        self.last_command = None
        self.last_heartbeat = None
        self.paused = False
        self.connected = False
        self.generation = 0
        self.last_summary = None
        self.acks = deque(maxlen=12)

    @property
    def prefix(self):
        return 'iot/' + self.device

    def on_connect(self, client, userdata, flags, reason_code, properties):
        with self.lock:
            self.connected = not reason_code.is_failure
            self.generation += 1
            self.state = None
            self.last_command = None
            self.last_heartbeat = None
        if self.connected:
            client.subscribe([(self.prefix + '/state', 0), (self.prefix + '/ack', 0)])
            self.emit('Broker povezan; čekam svježi state. Stare se naredbe ne ponavljaju.')
        else:
            self.emit('Broker je odbio vezu: ' + str(reason_code))

    def on_disconnect(self, client, userdata, flags, reason_code, properties):
        with self.lock:
            self.connected = False
            self.state = None
            self.last_command = None
            self.generation += 1
        self.emit('Veza s brokerom je prekinuta. Čekam novu razmjenu.')

    def publish(self, payload):
        if not self.connected or not self.client.is_connected():
            raise ValueError('Broker nije povezan; naredba nije spremljena za naknadno slanje.')
        info = self.client.publish(self.prefix + '/command', json.dumps(payload), qos=0, retain=False)
        if info.rc != mqtt.MQTT_ERR_SUCCESS:
            raise ValueError('Objava nije uspjela; pošalji novu naredbu nakon obnove veze.')

    def on_message(self, client, userdata, message):
        if message.retain:
            return  # Ne koristimo prethodno spremljeno stanje ni potvrdu.
        try:
            data = json.loads(message.payload.decode('utf-8'))
            if not isinstance(data, dict):
                return
            if message.topic == self.prefix + '/ack':
                if data.get('type') != 'ack' or data.get('device') != self.device:
                    return
                with self.lock:
                    if not self.state or any(data.get(k) != self.state.get(k) for k in ('boot_id', 'session_token')):
                        self.emit('ACK iz druge ili još nepotvrđene sesije nije potvrda trenutačne naredbe.')
                        return
                self.acks.append(data)
                self.emit('ACK: ' + json.dumps(data, ensure_ascii=False))
                return
            if message.topic != self.prefix + '/state' or data.get('type') != 'state' or data.get('device') != self.device:
                return
            if not all(isinstance(data.get(k), str) and data[k] for k in ('boot_id', 'session_token', 'challenge')):
                return
            with self.lock:
                old = self.state or {}
                if (old.get('boot_id'), old.get('session_token')) != (data['boot_id'], data['session_token']):
                    self.counter = 0
                    self.last_command = None
                    self.last_heartbeat = None
                    self.generation += 1
                self.state = data
                self.received = time.monotonic()
                last = data.get('last_cmd_id', 0)
                if isinstance(last, int) and not isinstance(last, bool) and 0 <= last <= 4294967295:
                    self.counter = max(self.counter, last)
                token = (data['boot_id'], data['session_token'], data['challenge'])
                if not self.paused and token != self.last_heartbeat:
                    hb = {k: data[k] for k in ('device', 'boot_id', 'session_token', 'challenge')}
                    hb['type'] = 'heartbeat'
                    self.publish(hb)
                    self.last_heartbeat = token
                summary = tuple(data.get(k) for k in ('app_online', 'reading_status', 'mode', 'target', 'alarm', 'actuatorArmed'))
                if summary != self.last_summary:
                    self.last_summary = summary
                    self.emit('STATE: online=%s, mjerenje=%s, način=%s, cilj=%s, alarm=%s, servoARM=%s' % summary)
        except (UnicodeDecodeError, ValueError, TypeError, KeyError) as exc:
            self.emit('Poruka nije obrađena: ' + str(exc))

    def delayed_publish(self, payload, generation):
        with self.lock:
            if generation != self.generation or self.paused or not self.connected:
                self.emit('Odgođeni pokus je odbačen zbog promjene veze/sesije ili PAUSE.')
                return
            try:
                self.publish(payload)
                self.emit('Poslan je izvorni izazov nakon 6,5 s; uređaj treba odbiti isteklu naredbu.')
            except ValueError as exc:
                self.emit(str(exc))

    def command(self, word):
        word = word.strip().upper()
        with self.lock:
            if word == 'STATUS':
                self.emit(json.dumps(self.state, ensure_ascii=False, indent=2))
                if self.state:
                    self.emit('Dob primitka na računalu: %.1f s; PAUSE=%s' % (time.monotonic() - self.received, self.paused))
                else:
                    self.emit('Stanje uređaja još nije primljeno; PAUSE=%s' % self.paused)
                return
            if word == 'PAUSE':
                self.paused = True
                self.generation += 1
                self.last_command = None
                self.emit('Heartbeat je pauziran. Prati app_online=false i povratak lokalnom AUTO.')
                return
            if word == 'RESUME':
                self.paused = False
                self.last_command = None
                self.emit('Heartbeat se nastavlja na sljedeći novi izazov. Stare naredbe nisu ponovljene.')
                return
            if word not in ('OPEN', 'CLOSE', 'AUTO', 'DUPLICATE', 'EXPIRED', 'BAD_SESSION', 'BAD_DEVICE', 'BAD_ACTION'):
                raise ValueError('Naredbe: OPEN CLOSE AUTO STATUS DUPLICATE EXPIRED BAD_SESSION BAD_DEVICE BAD_ACTION PAUSE RESUME HELP QUIT')
            if self.paused or not self.state or time.monotonic() - self.received > 6:
                raise ValueError('Nema svježe razmjene s uređajem ili je PAUSE aktivan.')
            if word == 'DUPLICATE':
                if self.last_command is None:
                    raise ValueError('Prvo pošalji OPEN/CLOSE/AUTO i pričekaj ACK.')
                payload = dict(self.last_command)
            else:
                if self.counter >= 4294967295:
                    raise ValueError('Dosegnut je kraj brojača; uspostavi novu sesiju uređaja.')
                self.counter += 1
                payload = {k: self.state[k] for k in ('device', 'boot_id', 'session_token', 'challenge')}
                payload.update(type='command', cmd_id=self.counter, ttl_ms=6000, command=word if word in ('OPEN', 'CLOSE', 'AUTO') else 'OPEN')
                if word == 'BAD_SESSION':
                    payload['session_token'] = '0000000000000000'
                elif word == 'BAD_DEVICE':
                    payload['device'] = 'drugi_uredaj'
                elif word == 'BAD_ACTION':
                    payload['command'] = 'ROTATE'
                elif word in ('OPEN', 'CLOSE', 'AUTO'):
                    self.last_command = dict(payload)
            if word == 'EXPIRED':
                timer = threading.Timer(6.5, self.delayed_publish, args=(payload, self.generation))
                timer.daemon = True
                timer.start()
                self.emit('Pokus čeka 6,5 s; heartbeat se nastavlja.')
            else:
                self.publish(payload)
                self.emit('Poslano; prihvat provjeri u ACK: ' + json.dumps(payload))


PAGE = """<!doctype html><html lang="hr"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Nadzor modela C2</title><style>body{font:18px Arial;max-width:980px;margin:30px auto;padding:0 20px}button{font:inherit;padding:10px;margin:5px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:14px;background:#f4f6f8;padding:18px}</style><h1>Nadzor vlastitog uređaja</h1><label>Promatrana oznaka <input id="selected" maxlength="24"><button onclick="refresh()">Prikaži moj uređaj</button></label><p id="device"></p><p>Pošalji jednu naredbu, pričekaj njezin ACK i kopiraj tražene retke u Word. Pauza nadzora ostavlja lokalno mjerenje aktivnim; nakon više od 6 s uređaj prelazi u AUTO.</p><div id="buttons"></div><p id="result" role="status"></p><h2>Stanje i potvrde</h2><pre id="state"></pre><script>const choices=[['OPEN','OPEN'],['CLOSE','CLOSE'],['AUTO','AUTO'],['DUPLICATE','Ponovi istu naredbu'],['BAD_ACTION','Nepoznata radnja'],['EXPIRED','Pošalji nakon isteka roka'],['PAUSE','Pauziraj nadzor'],['RESUME','Obnovi nadzor']];for(const [command,label] of choices){const b=document.createElement('button');b.textContent=label;b.onclick=async()=>{try{const r=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command,device:document.querySelector('#selected').value})});const v=await r.json();document.querySelector('#result').textContent=v.message||v.error;await refresh()}catch(e){document.querySelector('#result').textContent='Slanje nije potvrđeno.'}};document.querySelector('#buttons').append(b)}async function refresh(){try{const r=await fetch('/api/state?device='+encodeURIComponent(document.querySelector('#selected').value));const d=await r.json();if(!document.querySelector('#selected').value)document.querySelector('#selected').value=d.device;document.querySelector('#device').textContent='Uređaj '+d.device+' · nadzor '+(d.paused?'PAUZIRAN':'AKTIVAN');document.querySelector('#state').textContent=JSON.stringify(d,null,2)}catch(e){document.querySelector('#state').textContent='Usluga nije dostupna.'}}setInterval(refresh,1000);refresh();</script></html>"""

def web_handler(controller):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def reply(self,code,value,html=False):
            raw=value.encode() if html else json.dumps(value,ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header('Content-Type','text/html; charset=utf-8' if html else 'application/json; charset=utf-8')
            self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw)
        def do_GET(self):
            if self.path=='/': return self.reply(200,PAGE,True)
            if urlparse(self.path).path!='/api/state': return self.reply(404,{'error':'Nepoznata adresa.'})
            with controller.lock:
                selected=parse_qs(urlparse(self.path).query).get('device',[controller.device])[0]
                own=selected==controller.device
                self.reply(200,dict(device=selected,paused=controller.paused,broker_connected=controller.connected,state=controller.state if own else None,command=controller.last_command if own else None,acks=list(controller.acks) if own else []))
        def do_POST(self):
            try:
                if self.path!='/api/action' or self.headers.get('Content-Type','').split(';')[0]!='application/json':
                    raise ValueError('Očekuje se JSON radnja.')
                origin=self.headers.get('Origin')
                if origin and origin!='http://'+self.headers.get('Host',''): raise ValueError('Nedopušten izvor.')
                n=int(self.headers.get('Content-Length','0'))
                if not 0<n<=256: raise ValueError('Nevaljana duljina.')
                obj=json.loads(self.rfile.read(n));command=obj.get('command')
                if obj.get('device')!=controller.device: raise ValueError('Odaberi vlastiti uređaj.')
                if command not in ('OPEN','CLOSE','AUTO','DUPLICATE','BAD_ACTION','EXPIRED','PAUSE','RESUME'): raise ValueError('Nepoznata radnja.')
                controller.command(command)
                self.reply(200,{'message':'Postupak pokrenut. Provjeri novo stanje i odgovarajući ACK uređaja.'})
            except (ValueError,TypeError,AttributeError) as exc: self.reply(400,{'error':str(exc)})
    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', required=True, help='LAN adresa brokera')
    parser.add_argument('--port', type=int, default=1883)
    parser.add_argument('--device', default='u07')
    parser.add_argument('--http-host', default='127.0.0.1')
    parser.add_argument('--http-port', type=int, default=8081)
    parser.add_argument('--cli', action='store_true', help='Upravljanje konzolom umjesto preglednika')
    parser.add_argument('--user', default='nastavnik')
    args = parser.parse_args()
    import re
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,24}', args.device):
        parser.error('Oznaka uređaja ima 1–24 slova, brojke, _ ili -.')
    if not 1 <= args.port <= 65535:
        parser.error('Priključak brokera mora biti cijeli broj 1–65535.')
    password = getpass.getpass('MQTT lozinka korisnika ' + args.user + ': ')
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id='nastava-' + secrets.token_hex(4), clean_session=True, protocol=mqtt.MQTTv311)
    client.username_pw_set(args.user, password)
    controller = Controller(client, args.device)
    client.on_connect, client.on_disconnect, client.on_message = controller.on_connect, controller.on_disconnect, controller.on_message
    client.reconnect_delay_set(1, 5)
    try:
        client.connect(args.host, args.port, keepalive=15)
        client.loop_start()
        print('Privatna nastavna mreža; MQTT/TCP nije šifriran. Naredba HELP prikazuje izbor.')
        if not args.cli:
            print('Preglednik: http://%s:%s' % (args.http_host, args.http_port))
            with ThreadingHTTPServer((args.http_host,args.http_port), web_handler(controller)) as server:
                server.serve_forever()
        else:
            while True:
                word = input('mqtt> ').strip().upper()
                if word == 'QUIT':
                    break
                if word == 'HELP':
                    print('OPEN CLOSE AUTO STATUS DUPLICATE EXPIRED BAD_SESSION BAD_DEVICE BAD_ACTION PAUSE RESUME HELP QUIT')
                elif word:
                    try:
                        controller.command(word)
                    except ValueError as exc:
                        print(exc)
    except (KeyboardInterrupt, EOFError):
        pass
    except OSError as exc:
        print('Mrežna pogreška:', exc)
    finally:
        client.disconnect()
        client.loop_stop()


if __name__ == '__main__':
    main()
