LOKALNA HTTP USLUGA — PRIPREMA NASTAVNIKA

Potrebno: CPython 3.10 ili noviji na nastavničkom računalu; nema vanjskih paketa.
MicroPython je na ESP32. Ne kopirati http_server.py na pločicu.
U mapi ovog README-a otvori terminal i pokreni:
    python http_server.py --host 0.0.0.0 --port 8080
Na Windowsu po potrebi koristi py umjesto python; na Linuxu python3.
Provjeri lokalno http://127.0.0.1:8080/ pa s drugog računala http://LAN_IP:8080/.
Za učenike zapiši stvarnu LAN IPv4 adresu poslužitelja, port 8080, SSID i svakom
učeniku jedinstveni ID. Pločica koristi brojčani IP bez http:// i porta.

Izdvojena 2,4 GHz nastavna Wi-Fi mreža mora dopuštati međusobnu komunikaciju.
Na poslužitelju odobri dolazni TCP 8080 samo za tu izdvojenu mrežu; ne isključuj
cijeli vatrozid. Ne otvaraj port na usmjerivaču prema internetu. Nema TLS-a,
autentikacije ni zaštite korisničkih računa. Ovo nije produkcijska usluga.

ESP POST /api/update šalje stanje i dobiva HTTP 200 s odgovorom. Preglednik
GET /api/state čita kartice, POST /api/command predaje OPEN/CLOSE/AUTO.
HTTP 200 nije potvrda fizičkog pomaka. U kartici prati ack_id/ack_command/
ack_result, target, valjanost i zasebno fizičko opažanje.

Školska priprema za LV2.1, LV2.2 te HTTP dijelove LV2.3 i LV2.6: provjeri da je
usluga pokrenuta, da računalo zadržava istu IP adresu i da svaki učenik dobiva
vlastiti cjelovit projekt, ne tuđi već napravljeni program. Provedi početnu
provjeru s jednom pločicom prije sata. Na završetku zaustavi Ctrl+C i zatvori
odobreni nastavni servis ako se više ne koristi.

Granice provjere: uključeni automatizirani test potvrđuje lokalni HTTP razgovor
na računalu, ali ne radijski Wi-Fi, stvarni DS18B20, servo, instalirani MicroPython
ni točnost fizičkog sklopa. To se mora zasebno praktično ispitati.
