"""Lokalna usluga V2.1. CPython 3.10+; bez vanjskih paketa.
Samo izdvojena nastavna mreza: nema autentikacije ni TLS-a.
Pokretanje: python http_server.py --host 0.0.0.0 --port 8080
"""
import argparse
import json
import math
import re
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

STATE = {}
LOCK = threading.RLock()
SERVER_ID = secrets.token_hex(8)
COMMAND_TTL = 4.0
FRESH_SECONDS = 6.0
MAX_DEVICES = 40
PAGE = r'''<!doctype html><html lang="hr"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>V2.1 – put mjerenja i naredbe</title><style>
body{font:17px/1.45 system-ui;max-width:1050px;margin:28px auto;padding:0 18px}
article{border:1px solid #888;border-radius:8px;padding:18px;margin:16px 0}
h1,h2{line-height:1.2}button{font:inherit;margin:6px;padding:8px 16px}
pre{white-space:pre-wrap;overflow-wrap:anywhere}strong{font-weight:700}
small{display:block}.grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
</style><h1>V2.1 – povezani temperaturni model</h1>
<p>Preglednik → lokalna usluga → ESP32-S3. Samo izdvojena školska mreža.</p>
<p><strong>Potvrda naredbe i zadani cilj nisu mjerenje fizičkog položaja.</strong>
Naredbe: OPEN = otvori, CLOSE = zatvori, AUTO = lokalno automatsko upravljanje.</p>
<p id="message" role="status">Pričekaj prvi prijenos uređaja.</p><div id="models"></div>
<script>
let busy=false;
async function command(device,cmd){
 try{let r=await fetch('/api/command',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({device,command:cmd})});
 let x=await r.json();if(!r.ok)throw Error(x.error);
 document.getElementById('message').textContent='Usluga je zaprimila '+cmd+'; queued='+x.queued+' za '+device+'. Pričekaj potvrdu uređaja s istim brojem.';
 }catch(e){document.getElementById('message').textContent='Naredba nije potvrđena: '+e.message;}}
function text(tag,content){let el=document.createElement(tag);el.textContent=content;return el;}
async function refresh(){if(busy)return;busy=true;
 try{let r=await fetch('/api/state',{cache:'no-store'});if(!r.ok)throw Error('usluga');let s=await r.json();let box=document.getElementById('models');
 let openDetails=new Set(Array.from(box.querySelectorAll('details[open]')).map(d=>d.dataset.device));box.replaceChildren();
 for(let [id,d] of Object.entries(s)){let a=document.createElement('article'),x=d.state;
 let reachable=d.age<=6, age=d.sample_age_ms===null?null:d.sample_age_ms/1000;
 let fresh=reachable&&x.valid&&age!==null&&age<=6;
 a.append(text('h2',id+(x.simulated?' — SIMULACIJA, NIJE MJERENJE':'')));
 a.append(text('p','Novi podatci uređaja: '+(reachable?'DOSTUPNI':'NEDOSTUPNI')+'; zadnji prijenos prije '+d.age.toFixed(1)+' s.'));
 a.append(text('p','Temperatura: '+(fresh?Number(x.temp_c).toFixed(2)+' °C':'— (nema potvrđenog aktualnog valjanog rezultata)')));
 a.append(text('p','Valjani uzorak #'+x.sample_seq+'; oznaka pokretanja '+x.boot+'; status poslanog uzorka '+x.status+'.'));
 a.append(text('p','Izvor: '+x.source+'; ispitni korak '+(x.test_step||'—')+' '+(x.test_label||'')+'.'));
 a.append(text('p','Način i cilj iz zadnjeg prijenosa: '+x.mode+' / '+x.target+(reachable?'':' — povijesni podatak, sadašnje stanje nije potvrđeno')));
 a.append(text('p','Servo programski omogućen: '+(x.actuatorArmed?'DA':'NE')+'. LED21 pokazuje cilj.'));
 if(!x.alarm_enabled)a.append(text('p','LED47 označuje nevaljano ili zastarjelo mjerenje; nije pokazatelj Wi-Fi veze ni temperaturnog alarma u ovoj vježbi.'));
 a.append(text('p','Potvrda uređaja: #'+x.ack_id+' '+(x.ack_command||'—')+' '+x.ack_result+'.'));
 if(d.pending)a.append(text('p','Usluga čuva naredbu #'+d.pending.id+' '+d.pending.command+'; '+d.pending.status+'.'));
 for(let c of ['OPEN','CLOSE','AUTO']){let b=text('button',c);b.disabled=!reachable;b.onclick=()=>command(id,c);a.append(b);}
 let details=document.createElement('details');details.dataset.device=id;details.open=openDetails.has(id);details.append(text('summary','Izvorna poruka i vremena (za zapisnik)'));
 details.append(text('pre',JSON.stringify(x,null,2)+'\nStarost na usluzi [s]: '+d.age.toFixed(2)));a.append(details);box.append(a);}
 for(let [id,d] of Object.entries(s)){if(!d.exchange)continue;let a=text('article',''),q=d.exchange;
 a.append(text('h2','HTTP razmjena uređaja '+id));
 a.append(text('p',q.method+' '+q.path+' → HTTP '+q.http_status+'; request='+q.request));
 a.append(text('p','Usluga je obradila zahtjev i pripremila ovaj odgovor. To nije potvrda fizičkog pomaka niti neovisni dokaz da je uređaj primio odgovor.'));
 a.append(text('pre',JSON.stringify(q.response,null,2)));box.append(a);}
 }catch(e){document.getElementById('models').replaceChildren(text('p','Lokalna usluga nije dostupna. Trenutačno stanje uređaja ovdje nije potvrđeno.'));}
 finally{busy=false;}}
setInterval(refresh,1000);refresh();</script></html>'''

def hex_id(value):
    return isinstance(value, str) and re.fullmatch(r'[0-9a-f]{16}', value) is not None

def validate_state(b):
    if not hex_id(b.get('boot')) or not hex_id(b.get('session')):
        raise ValueError('oznaka pokretanja ili sesije')
    if type(b.get('request')) is not int or b['request'] < 1:
        raise ValueError('broj razmjene')
    if type(b.get('seq')) is not int or b['seq'] < 0:
        raise ValueError('broj uzorka')
    if any(type(b.get(k)) is not bool for k in ('valid','simulated','actuatorArmed')):
        raise ValueError('logicke vrijednosti')
    if b.get('unit') != 'degC' or b.get('mode') not in ('AUTO','MANUAL') or b.get('target') not in ('OPEN','CLOSED'):
        raise ValueError('jedinica/nacin/cilj')
    if not isinstance(b.get('status'), str) or len(b['status']) > 40:
        raise ValueError('status')
    age=b.get('sample_age_ms')
    if age is not None and (type(age) is not int or age < 0):
        raise ValueError('starost uzorka')
    for key in ('temp_c','raw_c'):
        x=b.get(key)
        if x is not None and (type(x) not in (int,float) or not math.isfinite(x)):
            raise ValueError('temperatura')
    if b['valid'] and (b.get('temp_c') is None or age is None or b['status'] != 'VALJANO'):
        raise ValueError('proturjecna valjanost')
    if type(b.get('ack_id')) is not int or b['ack_id'] < 0:
        raise ValueError('potvrda')
    if b.get('ack_command') not in (None,'AUTO','OPEN','CLOSE'):
        raise ValueError('potvrda naredbe')
    if not isinstance(b.get('ack_result'), str) or len(b['ack_result']) > 80:
        raise ValueError('rezultat potvrde')

class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.0'
    def setup(self):
        super().setup()
        self.connection.settimeout(3)

    def answer(self, code, content, mime='application/json; charset=utf-8'):
        raw=content.encode('utf-8') if isinstance(content,str) else json.dumps(content,ensure_ascii=False,allow_nan=False).encode('utf-8')
        self.send_response(code)
        for k,v in [('Content-Type',mime),('Content-Length',str(len(raw))),('Cache-Control','no-store'),('Connection','close'),('X-Content-Type-Options','nosniff')]:
            self.send_header(k,v)
        self.end_headers()
        try:self.wfile.write(raw)
        except (BrokenPipeError,ConnectionResetError,TimeoutError):pass

    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/':self.answer(200,PAGE,'text/html; charset=utf-8')
        elif path=='/api/state':
            now=time.monotonic()
            with LOCK:
                out={}
                for key,v in STATE.items():
                    pending=v.get('pending')
                    desc=None
                    if pending:
                        ack=v['state']['ack_id']==pending['id']
                        desc={'id':pending['id'],'command':pending['command'],
                              'status':v['state']['ack_result'] if ack else ('ISTEKLO BEZ POTVRDE' if now-pending['time']>COMMAND_TTL else 'CEKA POTVRDU')}
                    sample_age=None if v.get('sample_seen') is None else max(0,round((now-v['sample_seen'])*1000))
                    out[key]={'state':dict(v['state']),'age':now-v['seen'],'sample_age_ms':sample_age,'pending':desc,'exchange':v.get('exchange')}
            self.answer(200,out)
        else:self.answer(404,{'error':'putanja'})

    def do_POST(self):
        try:
            if self.headers.get('Transfer-Encoding'):
                raise ValueError('kodiranje nije podrzano')
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<=4096:raise ValueError('duljina')
            data=self.rfile.read(n)
            if len(data)!=n:raise ValueError('prekinuto tijelo')
            body=json.loads(data)
            if not isinstance(body,dict):raise ValueError('format')
            device=body.get('device')
            if not isinstance(device,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,24}',device):
                raise ValueError('oznaka uredjaja')
            path=urlparse(self.path).path
            now=time.monotonic()
            with LOCK:
                if path=='/api/update':
                    validate_state(body)
                    if device not in STATE and len(STATE)>=MAX_DEVICES:raise ValueError('previse uredjaja')
                    v=STATE.get(device)
                    previous=v
                    same_boot=previous is not None and previous['boot']==body['boot']
                    if same_boot and body['seq']<previous['state']['seq']:
                        raise ValueError('stari broj uzorka')
                    # Novi prijenos istog uzorka ne podmladjuje mjerenje.
                    same_sample=same_boot and previous['state'].get('sample_seq',previous['state']['seq'])==body.get('sample_seq',body['seq'])
                    sample_seen=previous.get('sample_seen') if same_sample else None
                    reported_age=body['sample_age_ms']
                    if reported_age is not None:
                        candidate=now-reported_age/1000.0
                        sample_seen=candidate if sample_seen is None else min(sample_seen,candidate)
                    if v is None or (v['boot'],v['session'])!=(body['boot'],body['session']):
                        v={'boot':body['boot'],'session':body['session'],'last_request':0,'counter':0,'pending':None}
                        STATE[device]=v
                    if body['request']<=v['last_request']:raise ValueError('stara/ponovljena razmjena')
                    v.update(state=body,seen=now,last_request=body['request'],sample_seen=sample_seen)
                    pending=v['pending']
                    command=None
                    if pending and now-pending['time']<=COMMAND_TTL and body['ack_id']!=pending['id']:
                        command=pending['command']
                    reply={'device':device,'boot':body['boot'],'session':body['session'],
                           'request':body['request'],'server':SERVER_ID,
                           'cmd_id':v['counter'],'command':command}
                    v['exchange']={'method':'POST','path':'/api/update','http_status':200,
                                   'request':body['request'],'response':dict(reply)}
                elif path=='/api/command':
                    if device not in STATE or body.get('command') not in ('AUTO','OPEN','CLOSE'):
                        raise ValueError('uredjaj/naredba')
                    v=STATE[device]
                    if now-v['seen']>FRESH_SECONDS:raise ValueError('nema aktualne veze s uredjajem')
                    v['counter']+=1
                    v['pending']={'id':v['counter'],'command':body['command'],'time':now}
                    reply={'queued':v['counter']}
                else:
                    self.answer(404,{'error':'putanja'});return
            self.answer(200,reply)
        except (ValueError,TypeError,UnicodeError,TimeoutError,ConnectionResetError) as err:
            self.answer(400,{'error':str(err)})

    def log_message(self,fmt,*args):
        print(time.strftime('%H:%M:%S'),self.address_string(),fmt%args)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host',default='127.0.0.1')
    parser.add_argument('--port',type=int,default=8080)
    args=parser.parse_args()
    if not 1<=args.port<=65535:parser.error('port mora biti 1–65535')
    print('V2.1. Posluzitelj:',args.host,'port',args.port)
    print('Samo izdvojena skolska mreza; bez autentikacije i TLS-a.')
    with ThreadingHTTPServer((args.host,args.port),Handler) as server:
        try:server.serve_forever()
        except KeyboardInterrupt:print('Zaustavljeno.')
if __name__=='__main__':main()
