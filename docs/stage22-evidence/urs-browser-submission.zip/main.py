from machine import Pin, ADC, PWM
from time import sleep_ms

# Krajevi potenciometra: 1 na 3V3, 3 na GND; klizac 2 na GPIO1.
adc = ADC(Pin(1), atten=ADC.ATTN_11DB)
led = PWM(Pin(4), freq=1000, duty_u16=0)
prethodno = -1
while True:
    vrijednost = adc.read_u16()
    led.duty_u16(vrijednost)
    postotak = vrijednost * 100 // 65535
    if postotak != prethodno:
        print("ADC:", vrijednost, "PWM:", postotak, "%")
        prethodno = postotak
    sleep_ms(30)
