# URS01 · GPIO, tipkalo i ADC → PWM

Varijanta: ADC i PWM
Učenik: Razvojni Pokus
Razred/grupa: TEST

Pripremljeno: 2026-11-14T11:06:38.915Z
SHA-256 programa i sklopa obaju čvorova: 5704ac6fa1c8d4af6a215a66ee01f7d626b930b1a1946143c19ea94032c60abc
Korisnik zabilježio pregled: 2026-11-14T11:06:34.035Z

Opažanja i pregled sadržaja unio je korisnik. Ovo nije automatska provjera ponašanja, ocjena ni potvrda autorstva. Hash otkriva promjenu sadržaja u odnosu na zapis, ali nije zaštita od krivotvorenja. Nastavnik treba izričito ponovno pokrenuti program.

## Opažanja

### Početni pokus

Razvojni pregled: pri 50 % klizača ADC 34888, PWM 53 %.

### Promjena

Klizač Home: ADC 0 / PWM 0 %. End: ADC 65535 / PWM 100 %.

### Pogreška i oporavak

Razvojna proba obrasca. U ovom pregledničkom pokusu odspajanje vodiča nije provedeno.

## Odgovori

### 1. Kako program povezuje fizički ulaz i izlaz? Navedi konkretne brojeve iz svojeg pokusa.

read_u16 očitava klizač, duty_u16 postavlja PWM. Opaženi su krajevi 0 i 65535.

### 2. Što je promjena vodiča pokazala i kako si potvrdio oporavak?

Kvar nije izveden u ovom obrascu za provjeru predaje.

## Nastavnički zapis

Nema nastavničkog zapisa.

Paket se otvara kao zaustavljena kopija. URS upute dolaze iz ugrađenog kataloga; sadržaj uvezenih uputa i preglednih zapisa ne izvršava se. SD i RTC sadrže samo izričito spremljene snimke.
