# URS01 · GPIO, tipkalo i ADC → PWM

Varijanta: ADC i PWM
Cilj: S3 · MicroPython
Procijenjeno trajanje: 60–90 min

Povezati ulaz, programsko očitanje i izlaz te usporediti raspone odabrane pločice.

## Prije početka

Poznaješ varijablu, uvjet i petlju. Najprije isprobaj LED, zatim tipkalo i tek onda ADC/PWM.

## Novi pojmovi

**GPIO** — Digitalni priključak čita ili postavlja razinu 0/1. Oznaka GPIO4 ili D9 označava priključak, a ne njegov redni položaj.

**ADC i referenca** — ADC napon pretvara u broj: AVR 0–1023, S3 C++ 0–4095, MicroPython read_u16 0–65535. S3 profil pri 11 dB zasićuje oko 3,1 V.

**PWM i pull-up** — PWM mijenja udio uključenja; pull-up određuje otvoreni ulaz. Tipkalo spojeno na GND uz pull-up aktivno je na 0.

## Spojevi i početni program

Klizač potenciometra ide na ADC GPIO1. read_u16 daje 0–65535; isti broj postavlja duty_u16. Model 11 dB zasićuje na 3,1 V.

Predložak je već spojen i sadrži izvršivi početni primjer. U Sastavljanju pregledaj stvarne vodiče i uvodni komentar/napomenu uz kod. Za promijenjeni C++ izvor treba novo prevođenje; početni prijevod je priložen.

## Postupak

1. Pročitaj pojmove i napomenu primjera. Pregledaj tablicu stvarnih veza i izvor/driver prije pokretanja.

2. Provjeri spojeve, pokreni i zabilježi početno stanje.

3. LED: postavi 250 ms uključeno i 750 ms isključeno. Tipkalo: usporedi otpušteno/pritisnuto. ADC: zapiši očitanje i PWM pri 0, 25, 50 i 100 %.

4. Zaustavi program, ukloni signalni vodič odabrane ulazne ili izlazne komponente, ponovno pokreni i usporedi. Vrati vodič.

5. Vrati valjan spoj/kod i potvrdi oporavak. Upiši sva opažanja i odgovore, zaustavi izvršavanje i zabilježi pregled sadržaja.

6. Izvezi URS predaju ZIP, zatim je uvezi kao kopiju i provjeri da sadrži kod, veze i odgovore. SD/RTC snimku najprije izričito sačuvaj.

## Očekivano opažanje

LED mijenja stanje, tipkalo mijenja izlaz ili pomicanje klizača mijenja PWM. Sredina S3 klizača zbog zasićenja nije točno polovica raspona.

## Pitanja

1. Kako program povezuje fizički ulaz i izlaz? Navedi konkretne brojeve iz svojeg pokusa.

2. Što je promjena vodiča pokazala i kako si potvrdio oporavak?

## Kriteriji nastavničkog pregleda

- Ispravno tumači aktivno nisku logiku ili razliku ADC/PWM raspona.

- Bilježi početni, izmijenjeni i pogrešni spoj te oporavak.

## Opseg dokaza

URS opažanja i pregled sadržaja unosi korisnik. Nisu automatska provjera ponašanja ni potvrda autorstva. Nastavnik treba ponovno pokrenuti program i pregledati stvarne rezultate. Izbor nastavničkog prikaza ne provodi autentifikaciju. Postojećih pet V vježbi zadržava svoju zasebnu automatsku provjeru.
