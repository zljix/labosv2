// D9 je oznaka priključka, a ne deveti fizički kontakt.
void setup() {
  pinMode(9, OUTPUT);
  pinMode(LED_BUILTIN, OUTPUT);
  Serial.begin(9600);
}
void loop() {
  digitalWrite(9, HIGH); digitalWrite(LED_BUILTIN, HIGH);
  Serial.print("LED=1 ms="); Serial.println(millis());
  delay(200);
  digitalWrite(9, LOW); digitalWrite(LED_BUILTIN, LOW);
  Serial.print("LED=0 ms="); Serial.println(millis());
  delay(200);
}
