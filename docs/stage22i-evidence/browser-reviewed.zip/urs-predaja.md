# URS01 · GPIO, tipkalo i ADC → PWM

Varijanta: LED i čekanje
Učenik: Probni učenik uno
Razred/grupa: 4.f

Pripremljeno: 2026-11-14T16:50:29.920Z
SHA-256 programa i sklopa obaju čvorova: 7227226e0c27e93b43c855366193cf1bc325a2dbf91fa7029ad69afbde44fb7f
Korisnik zabilježio pregled: 2026-11-14T16:42:14.934Z

Opažanja i pregled sadržaja unio je korisnik. Ovo nije automatska provjera ponašanja, ocjena ni potvrda autorstva. Hash otkriva promjenu sadržaja u odnosu na zapis, ali nije zaštita od krivotvorenja. Nastavnik treba izričito ponovno pokrenuti program.

## Opažanja

### Početni pokus

LED izmjenjuje stanja.

### Promjena

Dulje vrijeme daje dulji interval.

### Pogreška i oporavak

Bez vodiča nema svjetla; povratak vraća rad.

## Odgovori

### 1. Kako program povezuje fizički ulaz i izlaz? Navedi konkretne brojeve iz svojeg pokusa.

Obrazloženje 1

### 2. Što je promjena vodiča pokazala i kako si potvrdio oporavak?

Obrazloženje 2

## Nastavnički zapis

Podudara se s trenutačnim sadržajem · Pregledano
2026-11-14T16:49:32.317Z

Razvojni pregled u verziji 0.12.7: uvoz i povrat bilješke provjereni. Uno program zasebno ponovno pokrenut; LED=1/0 u konzoli. Bez stvarnog učeničkog pilota.

Paket se otvara kao zaustavljena kopija. URS upute dolaze iz ugrađenog kataloga; sadržaj uvezenih uputa i preglednih zapisa ne izvršava se. SD i RTC sadrže samo izričito spremljene snimke.
