@echo off
cd /d "%~dp0"
node scripts/avr-serve.mjs
pause
