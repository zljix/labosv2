@echo off
cd /d "%~dp0"
node scripts/avr-setup.mjs
pause
