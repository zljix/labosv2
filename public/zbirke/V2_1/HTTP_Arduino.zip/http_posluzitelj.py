#!/usr/bin/env python3
"""Gotova nastavna HTTP usluga za P13. Python 3.10+, samo standardna biblioteka.
Privatna nastavna mreza; HTTP nije sifriran. Ne objavljivati na internetu.
"""
import argparse
import collections
import hmac
import json
import re
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs

LOCK = threading.RLock()
DEVICES = {}
CONTROL_KEY = ''
MAX_BODY = 16384


def heartbeat(state):
    return {k: state[k] for k in ('device', 'boot_id', 'session_token', 'challenge')} | {'type': 'heartbeat'}


def reject_nonfinite_json(value):
    raise ValueError('Nedopustena nekonacna JSON vrijednost: ' + value)


def accept_state(state):
    if not isinstance(state, dict) or state.get('type') != 'state':
        raise ValueError('Ocekuje se type=state')
    # Reject NaN/Infinity, including numerical overflow such as 1e999, before
    # saving a state that could otherwise break the dashboard JSON response.
    json.dumps(state, allow_nan=False)
    for key in ('device', 'boot_id', 'session_token', 'challenge'):
        if not isinstance(state.get(key), str) or not state[key] or len(state[key]) > 64:
            raise ValueError('Neispravno polje ' + key)
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,32}', state['device']):
        raise ValueError('Neispravan device')
    now = time.monotonic()
    with LOCK:
        dev = DEVICES.setdefault(state['device'], {'state': {}, 'queue': collections.deque(), 'counter': 0,
                                                    'paused': False, 'last_command': None, 'events': collections.deque(maxlen=50)})
        if (dev['state'].get('boot_id'), dev['state'].get('session_token')) != (state['boot_id'], state['session_token']):
            dev['queue'].clear()
            dev['counter'] = 0
            dev['last_command'] = None
            dev['sample_seq'] = None
            dev['sample_received'] = None
            dev['events'].append('Nova sesija: odbacene su naredbe prethodne sesije.')
        seq = state.get('sample_seq')
        if isinstance(seq, int) and not isinstance(seq, bool) and 0 < seq <= 4294967295:
            if dev.get('sample_received') is None or seq != dev.get('sample_seq'):
                dev['sample_seq'] = seq
                dev['sample_received'] = now
        else:
            # A message without a usable sample number proves exchange only.
            dev['sample_seq'] = None
            dev['sample_received'] = None
        dev['state'] = state
        last_id = state.get('last_cmd_id', 0)
        if isinstance(last_id, int) and not isinstance(last_id, bool) and 0 <= last_id <= 4294967295:
            dev['counter'] = max(dev['counter'], last_id)
        dev['received'] = now
        return {} if dev['paused'] else heartbeat(state)


def queue_action(device, action, scenario='normal'):
    with LOCK:
        if device not in DEVICES:
            raise ValueError('Uredaj jos nije poslao podatke.')
        dev = DEVICES[device]
        if scenario == 'pause':
            dev['paused'] = True
            dev['queue'].clear()
            dev['events'].append('Pauzirani su heartbeat odgovori i isporuka naredbi.')
            return {'message': 'Prati prijelaz app_online u false i lokalni AUTO.'}
        if scenario == 'resume':
            dev['paused'] = False
            dev['events'].append('Obnovljena je razmjena. Stare naredbe nisu ponovljene.')
            return {'message': 'Razmjena nastavljena; posalji novu naredbu tek kad je veza spremna.'}
        if dev['paused'] or time.monotonic() - dev['received'] > 6:
            raise ValueError('Nema svjeze razmjene s uredajem.')
        if len(dev['queue']) >= 16:
            raise ValueError('Red je pun; pricekaj ili ponovo pokreni vezu.')
        if action not in ('OPEN', 'CLOSE', 'AUTO'):
            raise ValueError('Odaberi OPEN, CLOSE ili AUTO.')
        if scenario == 'duplicate':
            if not dev['last_command']:
                raise ValueError('Prvo posalji obicnu naredbu i pricekaj potvrdu.')
            cmd = dict(dev['last_command'])
        else:
            if dev['counter'] >= 4294967295:
                raise ValueError('Dosegnut je kraj brojača; ponovno uspostavi sesiju uređaja.')
            dev['counter'] += 1
            state = dev['state']
            cmd = {k: state[k] for k in ('device', 'boot_id', 'session_token', 'challenge')}
            cmd.update(type='command', cmd_id=dev['counter'], ttl_ms=6000, command=action)
            if scenario == 'bad_session':
                cmd['session_token'] = '0000000000000000'
            elif scenario == 'bad_device':
                cmd['device'] = 'drugi_uredaj'
            elif scenario == 'bad_action':
                cmd['command'] = 'ROTATE'
            elif scenario not in ('normal', 'expired'):
                raise ValueError('Nepoznat pokus.')
            if scenario == 'normal':
                dev['last_command'] = dict(cmd)
        due = time.monotonic() + (6.5 if scenario == 'expired' else 0)
        dev['queue'].append((due, cmd))
        dev['events'].append('U red: ' + json.dumps(cmd, ensure_ascii=False))
        return {'message': 'Naredba je stavljena u red; potvrdu prihvata daje uredaj.', 'command': cmd}


class Handler(BaseHTTPRequestHandler):
    server_version = 'NastavniHTTP/1.0'

    def log_message(self, format, *args):
        # Telemetry goes to the dashboard; do not log access keys or full request bodies.
        if self.path.startswith('/ui/action'):
            super().log_message(format, *args)

    def send_json(self, status, body):
        raw = json.dumps(body, ensure_ascii=False, allow_nan=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def body_json(self):
        length = int(self.headers.get('Content-Length', '0'))
        if not 0 < length <= MAX_BODY:
            raise ValueError('Nedopustena duljina zahtjeva.')
        return json.loads(self.rfile.read(length), parse_constant=reject_nonfinite_json)

    def do_GET(self):
        url = urlsplit(self.path)
        if url.path == '/':
            raw = Path(__file__).with_name('nadzorna_ploca.html').read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
        elif url.path == '/ui/state':
            with LOCK:
                now = time.monotonic()
                result = {key: {'state': val['state'], 'age_s': round(now - val['received'], 2),
                                'new_sample_age_s': (round(now - val['sample_received'], 2)
                                                     if val.get('sample_received') is not None else None),
                                'paused': val['paused'], 'queue': len(val['queue']), 'events': list(val['events'])}
                          for key, val in DEVICES.items()}
            self.send_json(200, result)
        elif url.path == '/api/command':
            q = parse_qs(url.query)
            device = q.get('device', [''])[0]
            session = q.get('session', [''])[0]
            cmd = {}
            with LOCK:
                dev = DEVICES.get(device)
                if dev and not dev['paused'] and session == dev['state']['session_token']:
                    # A delayed expiry test must not block a new ordinary command.
                    for i, (due, payload) in enumerate(dev['queue']):
                        if due <= time.monotonic():
                            cmd = payload
                            del dev['queue'][i]
                            break
            self.send_json(200, cmd)
        else:
            self.send_json(404, {'error': 'Nepostojeca adresa.'})

    def do_POST(self):
        try:
            if self.path == '/api/state':
                result = accept_state(self.body_json())
            elif self.path == '/ui/action':
                supplied = self.headers.get('Authorization', '').removeprefix('Bearer ')
                if not CONTROL_KEY or not hmac.compare_digest(supplied, CONTROL_KEY):
                    self.send_json(403, {'error': 'Za upravljanje treba nastavnikov kljuc. Prikaz je dostupan bez kljuca.'})
                    return
                body = self.body_json()
                if not isinstance(body, dict):
                    raise ValueError('Ocekuje se JSON objekt.')
                result = queue_action(body.get('device', ''), body.get('command', 'AUTO'), body.get('scenario', 'normal'))
            else:
                self.send_json(404, {'error': 'Nepostojeca adresa.'})
                return
            self.send_json(200, result)
        except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
            self.send_json(400, {'error': str(exc)})


def main():
    global CONTROL_KEY
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--host', default='0.0.0.0')
    ap.add_argument('--port', type=int, default=8080)
    args = ap.parse_args()
    CONTROL_KEY = secrets.token_urlsafe(12)
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print('Nadzorna ploca na nastavnickom racunalu: http://127.0.0.1:%d/' % args.port)
    print('S drugih uredaja koristi LAN IPv4 adresu ovoga racunala.')
    print('Kljuc za upravljanje (podijeli samo operatorima):', CONTROL_KEY)
    print('Privatna nastavna mreza; HTTP nije sifriran. Za prekid: Ctrl+C.')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
