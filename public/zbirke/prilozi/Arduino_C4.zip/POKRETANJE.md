# Nastavnička podrška C4 — usklađeno izdanje v12

Učenik koristi pripremljeni preglednik i svoj program. Poslužitelj, broker i
biblioteke priprema nastavnik prije sata. Detaljne pripreme i vrednovanje
nalaze se u nastavničkom priručniku v3.

## Pokretanje na računalu

U mapi Arduino_C4 ostavite aplikacija.py i nadzor.html zajedno. Pripremite
CPython 3.10 ili noviji i Mosquitto. U terminalu te mape:

```text
python -m venv .venv
```

Windows:

```text
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python aplikacija.py --device u07 --broker IP_BROKERA --probe-delay 3
```

Linux/macOS umjesto .venv\Scripts\python koristi .venv/bin/python.
Otvorite http://127.0.0.1:8084/ na računalu aplikacije. Za drugi uređaj pokrenite
zaseban proces s njegovim --device i drugim --http-port. Sučelje ove aplikacije
sluša samo lokalno; učenik radi na tom računalu.

## Broker i postavke uređaja

Za jednu probu na računalu koristite mosquitto_lokalno.conf. Za pločicu
iz mosquitto_skola.conf.example napravite svoju konfiguraciju: stvarni LAN IP
računala i apsolutne putanje do datoteke lozinki i ACL-a. Za prvi par računa:

```text
mosquitto_passwd -c lozinke.txt uredjaj_u07
mosquitto_passwd lozinke.txt aplikacija_u07
```

Opcija -c koristi se samo pri prvom stvaranju datoteke. Za sljedeće račune
izostavite -c. U kopiju mosquitto_skola.acl.example dodajte par korisnika i
njihove teme. Pokrenite broker s pripremljenom konfiguracijom. Za laboratorij
koristite odobrenu izdvojenu mrežu; ovaj MQTT/TCP profil nije šifriran.

Aplikacija čita C4_MQTT_USER i C4_MQTT_PASSWORD iz svojeg pokretačkog okruženja.
U odjeljak MREŽNE POSTAVKE odabrane .ino datoteke upišite isti UREDJAJ, Wi-Fi,
LAN IP brokera, port 1883 i vjerodajnice uređaja. 127.0.0.1 na ESP32 označuje
sam ESP32, a ne računalo. Tajne se uklanjaju iz učeničke predaje.

Za stvarni senzor i LED postavite SIMULACIJA=false, SENZOR_ODOBREN=true,
SERVO_OMOGUCEN=false. Za pripremljeni niz koristite SIMULACIJA=true; tada su
senzor i izlazi programski. Niz je 26 → 27 → 30 → nevaljano → 29 → 28 °C,
po 8 s; posljednji korak ostaje. SIM zapis nije fizičko mjerenje.

## Jednak zadatak na obje platforme

1. Pošalji OPEN, CLOSE pa AUTO; nakon svake naredbe pričekaj njezin uređajni
   odgovor s istim cmd_id. ACK potvrđuje obradu, a ne izmjeren položaj.
2. Odaberi Nepoznata radnja. Aplikacija šalje FLY s novim cmd_id. Priloži
   poslanu poruku i odbijeni odgovor s istim cmd_id te BAD_ACTION. Ta naredba
   ne smije promijeniti cilj. Lokalni AUTO i dalje smije reagirati na senzor.
3. Odaberi Odgoda 3 s. U istom dnevniku ESP32 poveži probe_start, novi
   sample_completed tijekom čekanja i probe_processed istog probe_id.
   Uspoređuje se samo sat uređaja; vrijeme računala nije vrijeme ESP32.
4. Pošalji CLOSE i potvrdi MANUAL/CLOSED. Odaberi Pauziraj nadzor. Wi-Fi,
   broker i program ostaju uključeni. Bez RESET-a čekaj više od 6 s:
   očekuj OFFLINE/AUTO uz nove lokalne uzorke.
5. Odaberi Obnovi nadzor. Očekuj ONLINE/AUTO; prethodni CLOSE ne ponavlja se.
   Za novi ručni cilj pošalji novu naredbu. Na kraju vrati AUTO i odgodu 0 s.

Dokaz pauze: tri lokalna retka, prije pauze, nakon isteka roka i nakon obnove.
U svakom označi uzorak, communication_state, mode i target. Ako trenutačna
valjana temperatura zahtijeva otvaranje, AUTO otvara; nevaljano mjerenje zatvara.

## Što nastavnik provjerava

Nakon povezivanja uređaj šalje aplikacijske izazove, a aplikacija ih potvrđuje.
Pauza zaustavlja te potvrde, ne vezu s brokerom. Više od 6000 ms bez valjane
potvrde poništava ručni način. Obnova koristi aktualnu sesiju i odbacuje stare
naredbe. Telemetrija i lokalno mjerenje ostaju aktivni tijekom pauze.

Teme su iot/ID/telemetry, iot/ID/state, iot/ID/alarm i iot/ID/command.
queued ili sent dokazuju samo predaju poruke aplikaciji; za prihvat/odbijanje
traži se uređajni odgovor. Ako ga nema, učenik bilježi BEZ POTVRDE.
LOG_DROPPED znači nepotpun dnevnik; takav slijed ne dokazuje cijeli pokus.

Dnevnik računala sprema se u dnevnik_aplikacije.jsonl. Prije rada razreda
nastavnik izvodi jednu probu na stvarnoj pločici i mreži. Programske provjere
u PROVJERA.txt ne potvrđuju fizički sklop ni školske uvjete.
