#!/usr/bin/env python3
"""Lokalna nadzorna aplikacija C4. Lozinke se citaju iz okoline, ne iz dnevnika."""
import argparse
from collections import deque
import heapq
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import threading
import time
import uuid
import paho.mqtt.client as mqtt


class Service:
    def __init__(self, device, delay=3.0, log_path=None):
        if not re.fullmatch(r'[a-zA-Z0-9_-]{1,16}', device):
            raise ValueError('Oznaka uređaja: 1–16 slova, znamenki, _ ili -')
        self.device = device
        self.delay = delay
        self.lock = threading.RLock()
        self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,
                                  client_id='c4-app-' + uuid.uuid4().hex[:12], clean_session=True)
        self.client.max_queued_messages_set(16)
        self.client.on_connect = self.on_connect
        self.client.on_disconnect = self.on_disconnect
        self.client.on_message = self.on_message
        self.connected = False
        self.paused = False
        self.lease = None
        self.lease_received = 0.0
        self.command_id = 0
        self.session_key = None
        self.last_command = None
        self.events = deque(maxlen=80)
        self.telemetry = {}
        self.pending = []
        self.counter = 0
        self.log_file = open(log_path, 'a', encoding='utf-8') if log_path else None

    def log(self, event, **fields):
        item = {'host_monotonic_s': round(time.monotonic(), 6), 'event': event, **fields}
        self.events.append(item)
        if self.log_file:
            self.log_file.write(json.dumps(item, ensure_ascii=False) + '\n')
            self.log_file.flush()

    def on_connect(self, client, userdata, flags, reason, properties):
        with self.lock:
            self.connected = not reason.is_failure
            self.lease = None
            self.pending.clear()
            self.log('broker_connected', success=self.connected)
            if self.connected:
                client.subscribe([(f'iot/{self.device}/{s}', 0)
                                  for s in ('state', 'telemetry', 'alarm')])

    def on_disconnect(self, client, userdata, flags, reason, properties):
        with self.lock:
            self.connected = False
            self.lease = None
            self.pending.clear()
            self.log('broker_disconnected')

    def send(self, payload):
        if not self.connected:
            raise ValueError('Broker nije povezan; poruka se ne čuva za kasnije.')
        body = json.dumps(payload, separators=(',', ':'), ensure_ascii=True).encode('ascii')
        if len(body) > 192:
            raise ValueError('Poruka prelazi 192 bajta.')
        info = self.client.publish(f'iot/{self.device}/command', body, qos=1, retain=False)
        if info.rc != mqtt.MQTT_ERR_SUCCESS:
            raise ValueError('MQTT klijent nije prihvatio objavu.')
        self.log('sent', topic=f'iot/{self.device}/command', message=payload, bytes=len(body))

    def on_message(self, client, userdata, packet):
        try:
            if len(packet.payload) > 2048 or packet.retain:
                return
            msg = json.loads(packet.payload)
            if not isinstance(msg, dict) or msg.get('device_id') != self.device:
                return
            if packet.topic != f'iot/{self.device}/{"telemetry" if msg.get("type")=="telemetry" else "alarm" if msg.get("type")=="alarm" else "state"}':
                return
            with self.lock:
                self.log('received', message=msg)
                if msg.get('type') == 'lease':
                    if not all(isinstance(msg.get(k), str) and
                               re.fullmatch(r'[a-zA-Z0-9_-]{1,24}', msg[k])
                               for k in ('boot_id', 'session_token')):
                        return
                    if type(msg.get('lease_id')) is not int or not 1 <= msg['lease_id'] <= 0xffffffff:
                        return
                    key = (msg['boot_id'], msg['session_token'])
                    floor = msg.get('last_cmd_id', 0)
                    if type(floor) is not int or not 0 <= floor <= 0xffffffff:
                        return
                    old_key = self.session_key
                    if key != old_key:
                        self.command_id = 0
                        self.last_command = None
                        self.pending.clear()
                    self.session_key = key
                    self.command_id = max(self.command_id, floor)
                    self.lease = {k: msg[k] for k in ('device_id', 'boot_id', 'session_token', 'lease_id')}
                    self.lease_received = time.monotonic()
                    if not self.paused:
                        self.send({'type': 'lease_ack', **self.lease})
                elif msg.get('type') == 'probe':
                    if self.paused:
                        return
                    if not self.lease or msg.get('boot_id') != self.lease['boot_id']:
                        return
                    if type(msg.get('probe_id')) is not int or not 1 <= msg['probe_id'] <= 0xffffffff:
                        return
                    if len(self.pending) >= 16:
                        self.log('probe_queue_full')
                        return
                    reply = {k: msg[k] for k in ('device_id', 'boot_id', 'probe_id')}
                    reply['type'] = 'probe_reply'
                    self.counter += 1
                    heapq.heappush(self.pending, (time.monotonic() + self.delay, self.counter, reply))
                elif msg.get('type') == 'telemetry':
                    self.telemetry = msg
        except (ValueError, UnicodeError, TypeError) as error:
            with self.lock:
                self.log('input_rejected', reason=str(error))

    def tick(self):
        # Odgoda probe_reply ne blokira MQTT dretvu ni lease_ack.
        with self.lock:
            now = time.monotonic()
            while self.pending and self.pending[0][0] <= now:
                _, _, reply = heapq.heappop(self.pending)
                if not self.paused and self.connected and self.lease and self.lease['boot_id'] == reply['boot_id']:
                    try:
                        self.send(reply)
                    except ValueError as error:
                        self.log('probe_rejected', reason=str(error))

    def act(self, action):
        with self.lock:
            if action in ('pause', 'resume'):
                self.paused = action == 'pause'
                self.pending.clear()
                self.last_command = None
                self.lease = None
                self.log('heartbeat_paused', paused=self.paused)
                return {'paused': self.paused}
            if not self.lease or time.monotonic() - self.lease_received > 4 or self.paused:
                raise ValueError('Nema nedavnog izazova uz aktivan nadzor. Pričekaj novu sesiju.')
            if action == 'duplicate':
                if not self.last_command:
                    raise ValueError('Najprije pošalji jednu naredbu.')
                msg = self.last_command.copy()
            elif action in ('OPEN', 'CLOSE', 'AUTO', 'test_wrong_device', 'test_unknown_action'):
                if self.command_id == 0xffffffff:
                    raise ValueError('Iscrpljen cmd_id; pokreni novu sesiju.')
                self.command_id += 1
                wire_action = 'OPEN' if action == 'test_wrong_device' else 'FLY' if action == 'test_unknown_action' else action
                msg = {'type': 'command', **self.lease, 'cmd_id': self.command_id, 'command': wire_action}
                if action == 'test_wrong_device':
                    # Pogreska samo u payloadu; tema i dalje pripada ovom uredjaju.
                    msg['device_id'] = 'test1' if self.device == 'test0' else 'test0'
                if action in ('OPEN', 'CLOSE', 'AUTO'):
                    self.last_command = msg.copy()
                else:
                    self.log('test_profile', profile=action, expected='WRONG_DEVICE' if action == 'test_wrong_device' else 'BAD_ACTION')
            else:
                raise ValueError('Nepoznata radnja.')
            self.send(msg)
            return {'queued': True, 'cmd_id': msg['cmd_id'], 'profile': action,
                    'meaning': 'Čeka se rezultat uređaja; objava nije prihvat ni položaj.'}

    def snapshot(self):
        with self.lock:
            return {'device': self.device, 'broker_connected': self.connected,
                    'heartbeat_paused': self.paused, 'probe_delay_s': self.delay,
                    'telemetry': self.telemetry, 'events': list(self.events)}


def make_handler(service):
    page = (Path(__file__).with_name('nadzor.html')).read_bytes()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def reply(self, code, body, content_type='application/json; charset=utf-8'):
            if not isinstance(body, bytes):
                body = json.dumps(body, ensure_ascii=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path == '/':
                self.reply(200, page, 'text/html; charset=utf-8')
            elif self.path == '/api/state':
                self.reply(200, service.snapshot())
            else:
                self.reply(404, {'error': 'Nema te putanje.'})

        def do_POST(self):
            # Lokalni UI, JSON i provjera podrijetla prije upravljanja.
            host = self.headers.get('Host', '')
            origin = self.headers.get('Origin')
            if host not in (f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'):
                self.reply(403, {'error': 'Koristi lokalnu adresu.'}); return
            if origin and origin not in (f'http://127.0.0.1:{self.server.server_port}', f'http://localhost:{self.server.server_port}'):
                self.reply(403, {'error': 'Nedopušteno podrijetlo.'}); return
            if self.path != '/api/action' or self.headers.get('Content-Type') != 'application/json':
                self.reply(400, {'error': 'Očekuje se JSON radnja.'}); return
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= 256:
                    raise ValueError('Nedopuštena duljina.')
                data = json.loads(self.rfile.read(length))
                if 'delay' in data:
                    delay = float(data['delay'])
                    if not 0 <= delay <= 10:
                        raise ValueError('Odgoda je između 0 i 10 s.')
                    with service.lock:
                        service.delay = delay
                    result = {'probe_delay_s': delay}
                else:
                    result = service.act(data.get('command'))
                self.reply(200, result)
            except (ValueError, TypeError, AttributeError) as error:
                self.reply(400, {'error': str(error)})
    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device', default='u07')
    parser.add_argument('--broker', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=1883)
    parser.add_argument('--http-port', type=int, default=8084)
    parser.add_argument('--probe-delay', type=float, default=3.0)
    parser.add_argument('--log', default='dnevnik_aplikacije.jsonl')
    args = parser.parse_args()
    if not 0 <= args.probe_delay <= 10:
        parser.error('--probe-delay: 0 do 10 s')
    service = Service(args.device, args.probe_delay, args.log)
    if os.environ.get('C4_MQTT_USER'):
        service.client.username_pw_set(os.environ['C4_MQTT_USER'], os.environ.get('C4_MQTT_PASSWORD', ''))
    http = ThreadingHTTPServer(('127.0.0.1', args.http_port), make_handler(service))
    threading.Thread(target=http.serve_forever, daemon=True).start()
    service.client.connect_async(args.broker, args.port, keepalive=3)
    service.client.loop_start()
    print(f'Otvori http://127.0.0.1:{args.http_port} za uređaj {args.device}', flush=True)
    try:
        while True:
            service.tick()
            time.sleep(.02)
    except KeyboardInterrupt:
        pass
    finally:
        http.shutdown()
        service.client.disconnect()
        service.client.loop_stop()
        if service.log_file:
            service.log_file.close()


if __name__ == '__main__':
    main()
