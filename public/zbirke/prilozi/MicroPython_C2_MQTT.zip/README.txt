NASTAVNIČKA PRIPREMA — MQTT SUČELJE ZA CJELINU 2

ŠTO JE OVDJE
mqtt_server.py — gotova CPython usluga na računalu.
index.html — gotova učenička stranica, mora biti uz mqtt_server.py.
requirements.txt — verzija paho-mqtt 2.1.0 za računalo, ne za ESP32.
mosquitto_ucionica.conf — konfiguracija stvarnog MQTT brokera.

Učenici ne izrađuju poslužitelj ni web-stranicu. Nastavnik priprema usluge
prije nastave, dodjeljuje jedinstven UREDAJ_ID i daje dvije različite adrese:
1. MQTT_BROKER = IP računala s brokerom; MQTT_PORT = 1883 za ESP32;
2. http://IP_RACUNALA_S_USLUGOM:8081/ za učenički preglednik.
Ako su broker i usluga na istom računalu, IP je jednak, ali protokol i port nisu.
Adresa 127.0.0.1 znači ovo računalo: ne upisuje se kao broker na ESP32.

SIGURNOSNI OPSEG
Ovaj paket nema korisničku prijavu, šifriranje TLS-om ni izolaciju prava po
učeniku. Namijenjen je isključivo fizički/logički izdvojenoj pouzdanoj
nastavnoj mreži bez pristupa neovlaštenih korisnika. Nije produkcijsko rješenje.
Ne izlagati internetom, ne uključivati prosljeđivanje portova i ne otvarati
vatrozid za sve javne mreže. TCP 1883 i 8081 dopuštaju se samo potrebnim
računalima/pločicama u nastavnoj podmreži. Ne isključivati cijeli vatrozid.
Učenik smije upravljati samo vlastitom dodijeljenom oznakom. Provjera Origin
zaglavlja i JSON-a smanjuje slučajne zahtjeve, ali nije autentikacija.
Mosquitto i usluga po mogućnosti slušaju samo na namjenskom LAN adapteru.

PRIPREMA NA NASTAVNIČKOM RAČUNALU (CPYTHON 3.10 ILI NOVIJI)
1. Instalirajte CPython s python.org i Mosquitto s mosquitto.org/download/.
   To su nastavničke instalacije prije sata. Na Windowsu provjerite postoji
   li već pokrenut Mosquitto servis: dva procesa ne mogu koristiti isti port.
2. Raspakirajte cijelu mapu MQTT u radnu mapu. Ne otvarajte HTML dvoklikom;
   stranica mora doći s usluge da bi HTTP zahtjevi išli na ispravno mjesto.
3. U terminalu otvorenom u toj mapi pripremite zasebno Python okruženje.
   Windows PowerShell:
      py -3 -m venv .venv
      .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   Linux/macOS:
      python3 -m venv .venv
      .venv/bin/python -m pip install -r requirements.txt
   Instalacija paketa zahtijeva pristup izvoru paketa. Za učionicu bez
   interneta nastavnik unaprijed priprema okruženje ili lokalnu kopiju wheel
   paketa i provjerava uvoz; učenik to ne radi tijekom vježbe.
4. U mosquitto_ucionica.conf provjerite listener. 0.0.0.0 sluša sve adaptere;
   sigurnije ga zamijenite stvarnim IPv4-om izdvojenog nastavnog adaptera.
   U ovoj izoliranoj demonstraciji allow_anonymous true dopušta veze bez
   lozinke; persistence false ne sprema poruke na disk. Nije za javnu mrežu.
5. Pokrenite broker u jednom nastavničkom terminalu. Ako je mosquitto u PATH-u:
      mosquitto -c mosquitto_ucionica.conf -v
   Primjer Windows PowerShella ako nije u PATH-u:
      & "C:\Program Files\mosquitto\mosquitto.exe" -c .\mosquitto_ucionica.conf -v
   Ako je postojeći servis već dogovoreno podešen za ovu nastavnu mrežu,
   koristite taj servis, ne pokrećite drugi broker.
6. U drugom terminalu pokrenite uslugu. Na Windowsu, broker na istom računalu:
      .\.venv\Scripts\python.exe mqtt_server.py --broker 127.0.0.1 --host 0.0.0.0 --port 8081
   Linux/macOS:
      .venv/bin/python mqtt_server.py --broker 127.0.0.1 --host 0.0.0.0 --port 8081
   Ako broker sluša samo na izdvojenom LAN IPv4-u, i --broker treba imati taj
   IPv4, ne 127.0.0.1. Ako je na drugom računalu, zadajte njegov IPv4.
   --host se također može ograničiti na izdvojeni LAN IPv4. Zadana adresa
   usluge bez --host je 127.0.0.1, dostupna samo na vlastitom računalu.
7. Na učeničkom računalu provjerite http://IP_USLUGE:8081/.
   Natpis 'Veza usluge s brokerom: USPOSTAVLJENA' pojavljuje se nakon odabira
   uređaja i uspostavljene veze. Bez pokrenutog ESP programa normalno je da
   nema njegove poruke. Usmjeravanje prema portu 8081 nije provjera MQTT 1883.
8. Provjerite odabrani MQTT program iz odgovarajuće mape V2.
   Pripremite jednak UREDAJ_ID u odjeljku POSTAVKE jedine .py datoteke i u pregledniku, nastavnu mrežu,
   MQTT_BROKER, MQTT_PORT i MREZA_OMOGUCENA=True. SERVO_OMOGUCEN ostaje False
   dok spoj, odobreni servo i vanjsko napajanje i slobodan hod nisu provjereni.
9. Tek nakon uspješne pokusne objave podijelite URL i dodijeljene oznake.
   Može se dati izravni URL http://IP_USLUGE:8081/?device=u07.
   Pokrenite jednu uslugu za cijelu učionicu, ne zasebnu za svaki preglednik.

ŠTO UČENIK RADI U SUČELJU
Upisuje svoj UREDAJ_ID u 'Oznaka vlastitog uređaja' i odabire 'Prikaži moj
uređaj'. Čita source, seq, boot, session, request, valid/status, starost,
mode/target, alarm i alarm_memory. Ako alarm_enabled nije true (V2.3–2.4),
sučelje umjesto temperaturnog alarma objašnjava da LED47 označuje nevaljano
ili zastarjelo mjerenje. U V2.5–2.6 prikazuje se uključena alarmna funkcija.
Ispitni ulaz ima vidljivu oznaku SIMULACIJA
— NIJE MJERENJE. OPEN, CLOSE i AUTO šalju jednu MQTT naredbu. Za novu naredbu
iste poruke čeka se sljedeći request; uređaj konačno provjerava prihvat.
Predaja MQTT klijentu nije dokaz primitka ni izvršenja. 'Trag posljednje
naredbe' prikazuje cmd_id i odgovarajući ACK. Bez ACK-a ishod nije potvrđen;
ne tvrdi se da naredba sigurno nije izvršena. Potvrda nije senzor položaja.
U 'Provjera odbijanja naredbi' dostupni su 'Ponovi posljednju naredbu (isti
cmd_id)', 'Pošalji nepoznatu radnju' i 'Pošalji pogrešan tip'. Očekuju se
ODBIJENO_DUPLIKAT, ODBIJENO_NAREDBA i ODBIJENO_IDENTITET bez novog djelovanja
aktuatora. Pogrešan tip namjerno šalje cmd_id kao tekst u navodnicima;
odbijeni ACK zadržava taj tip. Za pokus duplikata najprije pošaljite običnu
naredbu s valjanim cijelim brojem cmd_id. Cijele teme i JSON poruke
nalaze se u rasklopivim odjeljcima stanja, naredbe i potvrda.

ZAJEDNIČKI POKUS PAUZE NADZORA
Odaberi vlastiti ID. Pošalji zadanu ručnu naredbu i pričekaj odgovarajući ACK.
Klikni Pauziraj nadzor. Nakon više od 6 s lokalni zapis treba pokazati
OFFLINE/AUTO uz nove uzorke. Wi-Fi, broker i program ostaju uključeni.
Klikni Obnovi nadzor i pričekaj ONLINE/AUTO. Stara se naredba ne ponavlja.
Dokaz: tri lokalna zapisa prije pauze, nakon roka i nakon obnove.
PONG brokera ne potvrđuje nadzor aplikacije. Nema automatskog prekida
transporta ni postavke MREZNI_POKUS. V2.S sada također koristi 01_MQTT.
Pokus stare naredbe šalje izvorni izazov nakon 6,5 s; rok je 6 s.

NE RADI? PROVJERITE
- Broker nedostupan: broker proces/servis, njegov IPv4, listener, port1883 i
  pravilo vatrozida za nastavnu podmrežu. Ne očekujte udaljene veze ako je
  broker pokrenut samo u zadanom lokalnom načinu rada.
- Stranica nedostupna: usluga mora raditi, --host mora obuhvatiti nastavnički
  LAN adapter, učenik otvara IPv4 usluge i :8081, ne MQTT :1883.
- Stranica postoji, uređaja nema: isti UREDAJ_ID, Wi-Fi i broker u odjeljku POSTAVKE jedine .py datoteke,
  MREZA_OMOGUCENA=True, odabrana samostalna .py datoteka spremljena na pločici kao main.py.
- Gumbi privremeno sivi: nema dovoljno nove poruke/challengea, isti request
  već je iskorišten ili veza brokera nedostaje. Pričekajte novu objavu.
- Temperatura je crtica: provjerite valid/status/source i starost. Stari
  valjani broj nije aktualno mjerenje. JSON null nije temperatura 0 °C.
- ACK odbijen: pročitajte reason. Duplikat/nepoznata radnja namjerni su testovi;
  druge naredbe mogu biti odbijene zbog identiteta, starosti ili mjerenja/veze.
- Vrijeme računala jako je promijenjeno unatrag: zaustavite pokus, ispravite
  sat i ponovno pokrenite ESP i uslugu; cmd_id koristi rastući epoch-ms.
- Uspješna naredba bez pomaka: provjerite actuatorArmed, odvojeno napajanje,
  zajedničku masu, tablicu spajanja i mehanički hod. Ne zaključujte položaj
  samo iz target ili ACK. Prije promjene spoja isključite napajanja.

TEHNIČKA NAPOMENA I PROVJERA
Tema stanja je skola/iot/{UREDAJ_ID}/state; naredbe /command; potvrde /ack.
Usluga koristi MQTT3.1.1, QoS0, clean_session=True, retain=False; zadržane
poruke i stariji request ne osvježavaju aktualnost. Starost se dodatno prati
po (boot,seq): novi request ili nova session ne pomlađuju isti uzorak ni
ako ponovljena poruka pogrešno donese sample_age_ms=0. Nema automatskog ponovnog
slanja upravljačke naredbe nakon prekida. MQTT identiteti i challengei štite
od slučajnog starog ponavljanja; bez autentikacije ne štite od zlonamjernog
klijenta u istoj mreži. Uređaj je konačna provjera dopuštene radnje.
Opseg izvršenih računalnih provjera naveden je u PROVJERA.txt.
Programske provjere ne zamjenjuju ispitivanje ESP32-S3, radijske Wi-Fi veze,
senzora, servomotora i stvarnog nastavnog računala.

SLUŽBENI IZVORI (provjereno 30. 9. 2026.)
Eclipse Paho Python — API version2, MQTT klijent i mrežna petlja:
https://eclipse.dev/paho/clients/python/docs/
Eclipse Mosquitto — listener/allow_anonymous/persistence:
https://mosquitto.org/man/mosquitto-conf-5.html
Mosquitto2 — lokalni način rada bez listenera:
https://mosquitto.org/documentation/migrating-to-2-0/
Preuzimanje brokera: https://mosquitto.org/download/
