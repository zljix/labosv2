"""Lokalno učeničko sučelje za pravi MQTT; CPython 3.10+, paho-mqtt 2.x.

Preglednik pristupa HTTP-u, a ova usluga koristi MQTT preko stvarnog brokera.
Nema TLS-a ni prijave korisnika: samo izdvojena, pouzdana nastavna mreža.
Pokretanje: python mqtt_server.py --broker 127.0.0.1 --host 0.0.0.0
"""
from __future__ import annotations

import argparse
from collections import deque
import json
import logging
import math
from pathlib import Path
import re
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent
DEVICE_RE = re.compile(r"[A-Za-z0-9_-]{1,24}\Z")
HEX_RE = re.compile(r"[0-9a-f]{16}\Z")
FRESH_SECONDS = 6.0
COMMAND_SECONDS = 6.0
MAX_PAYLOAD = 4096
MAX_DEVICES = 40
MAX_SAFE_ID = 9007199254740991


def valid_device(value):
    return isinstance(value, str) and DEVICE_RE.fullmatch(value) is not None


def integer(value, minimum=0):
    return type(value) is int and minimum <= value <= MAX_SAFE_ID


def identity(obj):
    if not valid_device(obj.get("device")):
        raise ValueError("Nevaljana oznaka uređaja.")
    if any(not isinstance(obj.get(k), str) or not HEX_RE.fullmatch(obj[k])
           for k in ("boot", "session")):
        raise ValueError("Nevaljana oznaka pokretanja/sesije.")
    if not integer(obj.get("request"), 1):
        raise ValueError("Nevaljan broj razmjene.")


def validate_state(obj):
    identity(obj)
    if not integer(obj.get("seq")):
        raise ValueError("Nevaljan broj uzorka.")
    for key in ("valid", "simulated", "actuatorArmed", "alarm_memory"):
        if type(obj.get(key)) is not bool:
            raise ValueError("Nevaljano logičko polje: " + key)
    if "alarm_enabled" in obj and type(obj["alarm_enabled"]) is not bool:
        raise ValueError("Nevaljano logičko polje: alarm_enabled")
    if obj.get("unit") != "degC":
        raise ValueError("Nevaljana jedinica.")
    if obj.get("mode") not in ("AUTO", "MANUAL") or obj.get("target") not in ("OPEN", "CLOSED"):
        raise ValueError("Nevaljan način/cilj.")
    if obj.get("alarm") not in ("OFF", "ON", "UNKNOWN"):
        raise ValueError("Nevaljano stanje alarma.")
    if obj.get("status") not in ("VALJANO", "NEVALJANO", "ZASTARJELO", "NEMA_UZORKA"):
        raise ValueError("Nevaljan status uzorka.")
    if obj.get("source") not in ("DS18B20", "SIM") or obj["simulated"] != (obj["source"] == "SIM"):
        raise ValueError("Izvor uzorka i oznaka simulacije nisu usklađeni.")
    age = obj.get("sample_age_ms")
    if age is not None and not integer(age):
        raise ValueError("Nevaljana starost uzorka.")
    for key in ("temp_c", "raw_c"):
        value = obj.get(key)
        if value is not None and (type(value) not in (int, float) or not math.isfinite(value)):
            raise ValueError("Nevaljana temperatura.")
    if obj["valid"]:
        if obj.get("temp_c") is None or age is None or obj["status"] != "VALJANO":
            raise ValueError("Proturječna oznaka valjanosti.")
    elif obj.get("temp_c") is not None or obj["status"] == "VALJANO":
        raise ValueError("Nevaljano mjerenje ne smije imati aktualnu temperaturu.")


def validate_ack(obj):
    identity(obj)
    wrong_type_test = (isinstance(obj.get("cmd_id"), str)
                       and re.fullmatch(r"[0-9]{1,16}", obj["cmd_id"]) is not None
                       and obj.get("accepted") is False
                       and obj.get("reason") == "ODBIJENO_IDENTITET")
    if not (integer(obj.get("cmd_id"), 1) or wrong_type_test) or type(obj.get("accepted")) is not bool:
        raise ValueError("Nevaljana potvrda naredbe.")
    if obj.get("reason") not in (
        "PRIHVACENO", "ODBIJENO_DUPLIKAT", "ODBIJENO_IDENTITET",
        "ODBIJENO_STAROST", "ODBIJENO_NAREDBA", "ODBIJENO_MJERENJE_ILI_VEZA",
    ):
        raise ValueError("Nepoznat rezultat potvrde.")
    if obj["accepted"] != (obj["reason"] == "PRIHVACENO"):
        raise ValueError("Proturječan rezultat potvrde.")


class Store:
    """Stanje i provjere ne ovise o Pahou; jednostavno računalno testiranje."""
    def __init__(self, clock=time.monotonic, wall=time.time):
        self.clock, self.wall = clock, wall
        self.lock = threading.RLock()
        self.devices = {}
        self.connected = False
        self.error = "Veza s brokerom još nije uspostavljena."
        self.next_id = 0
        self.publisher = None

    def connection(self, connected, error=""):
        with self.lock:
            self.connected, self.error = connected, error
            if not connected:
                # Nakon ponovnog spajanja traži se nova, nezadržana poruka.
                for entry in self.devices.values():
                    entry["fresh_link"] = False

    def receive(self, topic, payload, retained=False):
        if retained:
            return False
        parts = topic.split("/")
        if len(parts) != 4 or parts[:2] != ["skola", "iot"] or parts[3] not in ("state", "ack"):
            raise ValueError("Nevaljana MQTT tema.")
        if len(payload) > MAX_PAYLOAD:
            raise ValueError("Prevelika MQTT poruka.")
        obj = json.loads(payload)
        if not isinstance(obj, dict) or obj.get("device") != parts[2]:
            raise ValueError("Tema i oznaka uređaja nisu jednake.")
        (validate_state if parts[3] == "state" else validate_ack)(obj)
        now = self.clock()
        with self.lock:
            entry = self.devices.get(parts[2])
            if parts[3] == "state":
                if entry is None:
                    if len(self.devices) >= MAX_DEVICES:
                        raise ValueError("Dosegnut je dopušten broj uređaja.")
                    entry = {"retired": deque(maxlen=20), "history": deque(maxlen=12),
                             "last_command": None, "pending": None, "used_request": None, "paused": False, "generation": 0}
                    self.devices[parts[2]] = entry
                old = entry.get("state")
                token = (obj["boot"], obj["session"])
                if token in entry["retired"]:
                    return False
                if old:
                    old_token = (old["boot"], old["session"])
                    if token == old_token and obj["request"] <= old["request"]:
                        return False
                    if obj["boot"] == old["boot"] and obj["seq"] < old["seq"]:
                        return False
                    if token != old_token:
                        entry["retired"].append(old_token)
                        entry["last_command"] = entry["pending"] = entry["used_request"] = None
                        entry["history"].clear()
                sample_token = (obj["boot"], obj.get("sample_seq", obj["seq"]))
                reported_age = obj["sample_age_ms"]
                if sample_token != entry.get("sample_token"):
                    sample_base = reported_age
                else:
                    sample_base = entry.get("sample_base")
                    if sample_base is not None:
                        sample_base += max(0, now-entry["sample_anchor"])*1000
                    if reported_age is not None:
                        sample_base = max(sample_base or 0, reported_age)
                # Isti (boot,seq) ne postaje mlađi novom objavom/requestom,
                # pa ni nakon reconnecta iste pločice s novom session.
                entry.update(sample_token=sample_token, sample_base=sample_base, sample_anchor=now)
                entry.update(state=obj, seen=now, fresh_link=True)
                if self.connected and self.publisher and not entry['paused']:
                    heartbeat = {k: obj[k] for k in ('device', 'boot', 'session', 'request')}
                    heartbeat['type'] = 'heartbeat'
                    self.publisher('skola/iot/'+parts[2]+'/command', heartbeat)
                return True
            if entry is None:
                return False
            state = entry["state"]
            command = entry.get("pending")
            if not command or any(obj[k] != command["payload"][k]
                                  for k in ("device", "boot", "session", "request", "cmd_id")):
                return False
            if (obj["boot"], obj["session"]) != (state["boot"], state["session"]):
                return False
            # ACK je odgovor programa, a ne mjerenje položaja servomotora.
            record = dict(obj, received_at=now)
            entry["history"].append(record)
            command["ack"] = record
            return True

    def snapshot(self, device):
        if not valid_device(device):
            raise ValueError("Upiši oznaku vlastitog uređaja (1–24 slova, znamenke, _ ili -).")
        with self.lock:
            now = self.clock()
            result = {"device": device, "broker_connected": self.connected,
                      "broker_message": self.error, "state": None,
                      "fresh_seconds": FRESH_SECONDS, "command_seconds": COMMAND_SECONDS}
            entry = self.devices.get(device)
            if not entry:
                return result
            pending = entry.get("pending")
            sample_age = entry["sample_base"]
            if sample_age is not None:
                sample_age = sample_age/1000 + max(0, now-entry["sample_anchor"])
            result.update(state=dict(entry["state"]), age=max(0, now-entry["seen"]),
                          effective_sample_age_seconds=sample_age,
                          fresh_link=entry["fresh_link"], supervision_paused=entry["paused"],
                          can_repeat=entry.get("last_command") is not None and integer(entry["last_command"]["cmd_id"], 1),
                          challenge_used=entry["used_request"] == entry["state"]["request"],
                          acks=[dict(a, age=max(0, now-a["received_at"])) for a in entry["history"]])
            if pending:
                age = max(0, now-pending["sent"])
                result["pending"] = {"payload": dict(pending["payload"]), "age": age,
                                     "test": pending["test"], "ack": pending.get("ack"),
                                     "status": "ACK" if pending.get("ack") else
                                     ("BEZ_POTVRDE" if age > COMMAND_SECONDS else "CEKA_ACK")}
            return result

    def supervise(self, device, paused):
        with self.lock:
            entry = self.devices.get(device)
            if not entry or type(paused) is not bool:
                raise ValueError('Najprije odaberi uređaj s primljenom porukom.')
            entry['paused'] = paused
            entry['generation'] += 1
            entry['last_command'] = entry['pending'] = None
            return {'message': 'Nadzor pauziran; pričekaj više od 6 s.' if paused else 'Nadzor se obnavlja sljedećom porukom. Stara naredba nije ponovljena.'}

    def delayed(self, device, payload, generation):
        with self.lock:
            entry = self.devices.get(device)
            if not entry or entry['paused'] or entry['generation'] != generation or not self.connected:
                return
            if any(payload[k] != entry['state'][k] for k in ('boot','session')):
                return
            self.publisher('skola/iot/'+device+'/command', payload)

    def command(self, device, action, repeat=False, bad_type=False, expired=False):
        if not valid_device(device):
            raise ValueError("Nevaljana oznaka uređaja.")
        if action not in ("OPEN", "CLOSE", "AUTO", "NEPOZNATO") and not repeat:
            raise ValueError("Nepodržana radnja sučelja.")
        if sum(bool(x) for x in (repeat, bad_type, expired)) > 1:
            raise ValueError("Odaberi samo jedan pokus odbijanja.")
        with self.lock:
            now = self.clock()
            entry = self.devices.get(device)
            if not self.connected or self.publisher is None:
                raise ValueError("Nema veze usluge s brokerom; ništa nije poslano.")
            if not entry or not entry["fresh_link"] or now-entry["seen"] >= COMMAND_SECONDS:
                raise ValueError("Nema dovoljno nove poruke uređaja. Pričekaj novi prijenos.")
            if entry['paused']:
                raise ValueError('Najprije obnovi nadzor i pričekaj ONLINE.')
            state = entry["state"]
            if state.get('communication_state') != 'ONLINE':
                raise ValueError('Pričekaj ONLINE prije naredbe.')
            if repeat:
                if not entry.get("last_command"):
                    raise ValueError("Najprije pošalji jednu naredbu.")
                payload = dict(entry["last_command"])
                if not integer(payload["cmd_id"], 1):
                    raise ValueError("Najprije pošalji naredbu s valjanim cijelim brojem cmd_id.")
                if (payload["boot"], payload["session"]) != (state["boot"], state["session"]):
                    raise ValueError("Sesija uređaja promijenila se; stara naredba neće biti ponovljena.")
            else:
                if entry["used_request"] == state["request"]:
                    raise ValueError("Za ovu poruku naredba je već poslana. Pričekaj novi prijenos.")
                self.next_id = max(self.next_id+1, int(self.wall()*1000))
                if not integer(self.next_id, 1):
                    raise ValueError("Nevaljan sat poslužitelja.")
                payload = {key: state[key] for key in ("device", "boot", "session", "request")}
                payload.update(cmd_id=str(self.next_id) if bad_type else self.next_id, command=action)
            # QoS 0, retain=False: bez naknadne dostave stare upravljačke naredbe.
            if expired:
                # Sadrzaj/izazov ostaju isti; dostava tek nakon 6,5 s > lokalni rok 6 s.
                from threading import Timer
                timer = Timer(6.5, self.delayed, args=(device, dict(payload), entry["generation"]))
                timer.daemon = True
                timer.start()
            else:
                self.publisher("skola/iot/"+device+"/command", payload)
            entry["used_request"] = state["request"]
            if not repeat:
                entry["last_command"] = dict(payload)
            entry["pending"] = {"payload": dict(payload), "sent": now,
                                "test": "ZASTARJELO" if expired else "DUPLIKAT" if repeat else ("POGRESAN_TIP" if bad_type else
                                         ("NEPOZNATA_RADNJA" if action == "NEPOZNATO" else None))}
            return {"published": True, "payload": payload,
                    "message": "Poruka je predana MQTT klijentu; pričekaj odgovarajući ACK uređaja."}


class MQTTBridge:
    def __init__(self, store, host, port):
        import paho.mqtt.client as mqtt
        self.mqtt, self.store = mqtt, store
        self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,
                                  client_id="ucionica-ui-"+secrets.token_hex(5),
                                  clean_session=True, protocol=mqtt.MQTTv311)
        self.client.on_connect = self.on_connect
        self.client.on_disconnect = self.on_disconnect
        self.client.on_connect_fail = self.on_connect_fail
        self.client.on_message = self.on_message
        self.client.reconnect_delay_set(min_delay=1, max_delay=8)
        store.publisher = self.publish
        self.client.connect_async(host, port, keepalive=15)
        self.client.loop_start()

    def on_connect(self, client, userdata, flags, reason_code, properties):
        if reason_code != 0:
            self.store.connection(False, "Broker je odbio vezu: "+str(reason_code))
            return
        rc, _ = client.subscribe([("skola/iot/+/state", 0), ("skola/iot/+/ack", 0)])
        self.store.connection(rc == self.mqtt.MQTT_ERR_SUCCESS,
                              "" if rc == self.mqtt.MQTT_ERR_SUCCESS else "Pretplata nije poslana.")

    def on_disconnect(self, client, userdata, flags, reason_code, properties):
        self.store.connection(False, "Veza usluge s brokerom prekinuta je.")

    def on_connect_fail(self, client, userdata):
        self.store.connection(False, "Broker nije dostupan. Nastavnik provjerava adresu, port i uslugu.")

    def on_message(self, client, userdata, message):
        try:
            self.store.receive(message.topic, message.payload, message.retain)
        except (ValueError, TypeError, UnicodeError, OverflowError) as err:
            logging.warning("MQTT poruka nije prihvaćena: %s", err)

    def publish(self, topic, payload):
        if not self.client.is_connected():
            raise ValueError("Veza s brokerom prekinuta je; nema potvrde dostave.")
        info = self.client.publish(topic, json.dumps(payload, allow_nan=False), qos=0, retain=False)
        if info.rc != self.mqtt.MQTT_ERR_SUCCESS:
            raise ValueError("Naredba nije predana MQTT klijentu: "+str(info.rc))

    def close(self):
        self.client.disconnect()
        self.client.loop_stop()


def handler_for(store):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.0"

        def setup(self):
            super().setup()
            self.connection.settimeout(3)

        def answer(self, code, data, mime="application/json; charset=utf-8"):
            raw = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False, allow_nan=False).encode("utf-8")
            self.send_response(code)
            for key, value in (("Content-Type", mime), ("Content-Length", str(len(raw))),
                               ("Cache-Control", "no-store"), ("Connection", "close"),
                               ("X-Content-Type-Options", "nosniff")):
                self.send_header(key, value)
            self.end_headers()
            try:
                self.wfile.write(raw)
            except (BrokenPipeError, ConnectionResetError, TimeoutError):
                pass

        def do_GET(self):
            path = urlparse(self.path)
            if path.path == "/":
                self.answer(200, (ROOT/"index.html").read_bytes(), "text/html; charset=utf-8")
            elif path.path == "/api/state":
                try:
                    device = parse_qs(path.query).get("device", [""])[0]
                    self.answer(200, store.snapshot(device))
                except ValueError as err:
                    self.answer(400, {"error": str(err)})
            else:
                self.answer(404, {"error": "Putanja ne postoji."})

        def do_POST(self):
            try:
                if urlparse(self.path).path not in ("/api/command", "/api/supervision"):
                    self.answer(404, {"error": "Putanja ne postoji."})
                    return
                if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
                    raise ValueError("Očekuje se JSON.")
                if self.headers.get("Transfer-Encoding"):
                    raise ValueError("Kodiranje tijela nije podržano.")
                origin = self.headers.get("Origin")
                if origin and origin != "http://"+self.headers.get("Host", ""):
                    raise ValueError("Zahtjev ne dolazi s ove stranice.")
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= MAX_PAYLOAD:
                    raise ValueError("Nevaljana duljina zahtjeva.")
                raw = self.rfile.read(length)
                if len(raw) != length:
                    raise ValueError("Nepotpuno tijelo zahtjeva.")
                body = json.loads(raw)
                if not isinstance(body, dict) or any(type(body.get(key, False)) is not bool for key in ("repeat", "bad_type", "expired")):
                    raise ValueError("Nevaljan zahtjev.")
                if urlparse(self.path).path == '/api/supervision':
                    self.answer(200, store.supervise(body.get('device'), body.get('paused')))
                    return
                self.answer(200, store.command(body.get("device"), body.get("command"), body.get("repeat", False), body.get("bad_type", False), body.get("expired", False)))
            except (ValueError, TypeError, UnicodeError, OverflowError, TimeoutError, ConnectionResetError) as err:
                self.answer(400, {"error": str(err)})

        def log_message(self, fmt, *args):
            logging.info("%s %s", self.address_string(), fmt % args)

    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1", help="Adresa HTTP sučelja; 0.0.0.0 samo u izdvojenoj učionici.")
    parser.add_argument("--port", type=int, default=8081)
    parser.add_argument("--broker", default="127.0.0.1")
    parser.add_argument("--broker-port", type=int, default=1883)
    args = parser.parse_args()
    if any(not 1 <= p <= 65535 for p in (args.port, args.broker_port)):
        parser.error("Portovi moraju biti između 1 i 65535.")
    if not (ROOT/"index.html").is_file():
        parser.error("Uz mqtt_server.py mora biti index.html.")
    logging.basicConfig(level=logging.WARNING)
    store = Store()
    try:
        bridge = MQTTBridge(store, args.broker, args.broker_port)
    except ImportError:
        parser.error("Nastavnik treba instalirati requirements.txt u CPython, ne na ESP32.")
    print("MQTT učionica: HTTP", args.host, args.port, "| broker", args.broker, args.broker_port)
    print("Samo izdvojena pouzdana nastavna mreža. Bez TLS-a i prijave. Ctrl+C završava uslugu.")
    try:
        with ThreadingHTTPServer((args.host, args.port), handler_for(store)) as server:
            server.serve_forever()
    except KeyboardInterrupt:
        print("Usluga zaustavljena.")
    finally:
        bridge.close()


if __name__ == "__main__":
    main()
