"""Školski TCP/JSON poslužitelj za CPython 3 na računalu.

Jedan zahtjev i jedan odgovor po vezi. Preglednik: port 8084.
Popis uređaja priprema nastavnik u scenariji.json;
konzola služi samo zapisima. Pokretanje ovog programa na ESP32 nije predviđeno.
"""
import argparse
import asyncio
import json
import time
from pathlib import Path

MAX_LINE = 2048  # bajtova, uključujući završni LF
SCENARIOS = {"NORMAL", "DELAY", "INVALID", "DUPLICATE", "TIMEOUT", "PREKID"}
INVALID_KINDS = {"DEVICE", "BOOT", "ACTION", "TYPE", "JSON"}
DEFAULT_PROFILE = {
    "scenario": "NORMAL", "request_id": 0, "command": "AUTO",
    "delay_ms": 3000, "timeout_ms": 5000, "invalid_kind": "ACTION",
}


def reject_constant(value):
    raise ValueError("JSON ne prihvaća NaN ni beskonačnost: " + value)


def json_loads(data):
    return json.loads(data, parse_constant=reject_constant)


def json_line(obj):
    line = (json.dumps(obj, ensure_ascii=False, separators=(",", ":"),
                       allow_nan=False) + "\n").encode("utf-8")
    if len(line) > MAX_LINE:
        raise ValueError("Odgovor premašuje 2048 bajtova")
    return line


async def read_line(reader):
    """Ograniči prikupljanje prije parsiranja, uključujući završni LF."""
    data = bytearray()
    while len(data) < MAX_LINE:
        part = await reader.read(1)
        if not part:
            raise ValueError("EOF prije dovršenoga retka")
        data.extend(part)
        if part == b"\n":
            if len(data) == 1:
                raise ValueError("Prazan redak")
            return bytes(data)
    raise ValueError("Predug redak ili nema LF unutar 2048 bajtova")


def telemetry_identity(obj):
    if not isinstance(obj, dict) or obj.get("type") != "telemetry":
        raise ValueError("Očekuje se objekt type=telemetry")
    device = obj.get("device_id")
    boot = obj.get("boot_id")
    sequence = obj.get("sequence")
    if not isinstance(device, str) or not 1 <= len(device) <= 32:
        raise ValueError("device_id mora biti tekst duljine 1–32")
    if not isinstance(boot, str) or not 1 <= len(boot) <= 64:
        raise ValueError("boot_id mora biti tekst duljine 1–64")
    if type(sequence) is not int or sequence < 0:
        raise ValueError("sequence mora biti nenegativan cijeli broj")
    return device, boot, sequence


class SchoolServer:
    def __init__(self, config_path, logger=None, receive_timeout_s=5.0):
        self.config_path = Path(config_path)
        self.sessions = {}  # (device_id, boot_id); hot reload ne briše ovu mapu
        self.consumed_requests = {}  # device_id; RESET ne ponavlja staru radnju
        self.logger = logger or self.print_event
        self.receive_timeout_s = receive_timeout_s

    @staticmethod
    def print_event(event):
        print(json.dumps(event, ensure_ascii=False, separators=(",", ":"),
                         allow_nan=False), flush=True)

    def log(self, event, **fields):
        self.logger(dict(event=event, server_ms=int(time.monotonic() * 1000), **fields))

    def profile(self, device):
        # Datoteka se ponovno čita za svaku telemetriju. Pri pogrešci se ne
        # izvršava prethodna radnja: veza se zatvara i u dnevniku ostaje uzrok.
        config = json_loads(self.config_path.read_text(encoding="utf-8"))
        if not isinstance(config, dict):
            raise ValueError("Scenariji moraju biti JSON objekt")
        defaults = config.get("defaults", {})
        devices = config.get("devices", {})
        if not isinstance(defaults, dict) or not isinstance(devices, dict):
            raise ValueError("defaults i devices moraju biti objekti")
        custom = devices.get(device, {})
        if not isinstance(custom, dict):
            raise ValueError("Profil uređaja mora biti objekt")
        p = dict(DEFAULT_PROFILE)
        p.update(defaults)
        p.update(custom)
        if p["scenario"] not in SCENARIOS:
            raise ValueError("Nepoznat scenario")
        if type(p["request_id"]) is not int or p["request_id"] < 0:
            raise ValueError("request_id mora biti nenegativan cijeli broj")
        if p["command"] not in {"OPEN", "CLOSE", "AUTO"}:
            raise ValueError("action mora biti OPEN, CLOSE ili AUTO")
        if p["invalid_kind"] not in INVALID_KINDS:
            raise ValueError("Nepoznat invalid_kind")
        for key in ("delay_ms", "timeout_ms"):
            if type(p[key]) is not int or not 0 <= p[key] <= 60000:
                raise ValueError(key + " mora biti cijeli broj 0–60000")
        return p

    def prepare_reply(self, identity, p):
        device, boot, sequence = identity
        state = self.sessions.setdefault((device, boot),
            {"last_cmd_id": 0, "last_action": "AUTO"})
        base = {"type": "no_command", "device_id": device,
                "boot_id": boot, "sequence": sequence}
        scenario = p["scenario"]
        if scenario == 'PREKID':
            self.consumed_requests[device] = max(p['request_id'], self.consumed_requests.get(device, 0))
            return json_line(dict(base, type='app_paused'))
        if scenario == 'TIMEOUT':
            return None
        if p["request_id"] <= self.consumed_requests.get(device, 0):
            return json_line(base)
        # Oznaka se troši prije odgode: ponovni zahtjev nije druga ista naredba.
        self.consumed_requests[device] = p["request_id"]
        if scenario == "DUPLICATE":
            if not state["last_cmd_id"]:
                self.log("NO_PREVIOUS_COMMAND", device_id=device, boot_id=boot)
                return json_line(base)
            command_id = state["last_cmd_id"]
            action = state["last_action"]
        else:
            state["last_cmd_id"] += 1
            command_id = state["last_cmd_id"]
            action = p["command"]
            state["last_action"] = action
        reply = dict(base, type="command", cmd_id=command_id, command=action)
        if scenario == "INVALID":
            kind = p["invalid_kind"]
            if kind == "DEVICE":
                reply["device_id"] = "other-device"
                if device == "other-device":
                    reply["device_id"] = "different-device"
            elif kind == "BOOT":
                reply["boot_id"] = "old-boot"
                if boot == "old-boot":
                    reply["boot_id"] = "different-boot"
            elif kind == "ACTION":
                reply["command"] = "FLY"
            elif kind == "TYPE":
                reply["cmd_id"] = True  # bool nije ugovoreni cijeli broj
            elif kind == "JSON":
                return b'{"type":broken}\n'
        return json_line(reply)

    async def handle(self, reader, writer):
        identity = None
        try:
            line = await asyncio.wait_for(read_line(reader), self.receive_timeout_s)
            obj = json_loads(line.decode("utf-8"))
            identity = telemetry_identity(obj)
            device, boot, sequence = identity
            self.log("RX", device_id=device, boot_id=boot, sequence=sequence,
                     telemetry=obj)
            if isinstance(obj.get("ack"), dict):
                self.log("ACK", device_id=device, boot_id=boot, sequence=sequence,
                         ack=obj["ack"])
            p = self.profile(device)
            reply = self.prepare_reply(identity, p)
            self.log("SCENARIO", device_id=device, boot_id=boot, sequence=sequence,
                     scenario=p["scenario"], request_id=p["request_id"])
            if p["scenario"] == "TIMEOUT":
                await asyncio.sleep(p["timeout_ms"] / 1000.0)
                self.log("TIMEOUT_WITHOUT_REPLY", device_id=device, boot_id=boot,
                         sequence=sequence)
                return
            if p["scenario"] == "DELAY":
                await asyncio.sleep(p["delay_ms"] / 1000.0)
            current = self.profile(device)
            if current['scenario'] == 'PREKID':
                reply = self.prepare_reply(identity, current)
            elif current != p:
                reply = json_line(dict(type='no_command', device_id=device, boot_id=boot, sequence=sequence))
            writer.write(reply)
            await asyncio.wait_for(writer.drain(), 1.0)
            self.log("REPLY", device_id=device, boot_id=boot, sequence=sequence,
                     response_line=reply.decode("utf-8").rstrip("\n"))
        except (ValueError, KeyError, TypeError, OSError, UnicodeError,
                asyncio.TimeoutError) as error:
            self.log("ERROR", identity=identity, reason=type(error).__name__,
                     detail=str(error))
        finally:
            writer.close()
            try:
                await asyncio.wait_for(writer.wait_closed(), 1.0)
            except (OSError, asyncio.TimeoutError):
                pass


from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse,parse_qs
from collections import deque
import threading

UI_PAGE = '''<!doctype html><html lang="hr"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Moja vježba C4</title><style>body{font:18px Arial;max-width:900px;margin:32px auto;padding:0 20px;background:#f3f6f9;color:#132839}input,button{font:inherit;padding:10px;margin:4px}button{cursor:pointer;border:1px solid #899dac;border-radius:6px;background:white}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:white;padding:20px;font-size:14px;border-radius:8px}h1{font-size:28px}</style><h1>Upravljanje vlastitim uređajem</h1><p>1. Upiši dodijeljeni ID. 2. Pričekaj novi zapis. 3. Pošalji jednu naredbu i pronađi njezin ACK.</p><label>Oznaka uređaja <input id="id" value="u07" maxlength="32"></label><button onclick="load()">Prikaži</button><p id="msg" role="status"></p><div id="buttons"></div><p>ACK potvrđuje obradu naredbe; fizički pomak opažaj zasebno. Retke potrebne za dokaz kopiraj u svoj Word.</p><pre id="state">Čekam odabir.</pre><script>const choices=[['OPEN','Otvori'],['CLOSE','Zatvori'],['AUTO','Automatski'],['INVALID','Nepoznata radnja'],['DUPLICATE','Ponovi istu naredbu'],['DELAY','Odgoda 3 s'],['PREKID','Pauziraj nadzor'],['NORMAL','Obnovi nadzor'],['NORMAL','Odgoda 0 s']];for(const [action,label] of choices){const b=document.createElement('button');b.textContent=label;b.onclick=()=>send(action);document.querySelector('#buttons').append(b);}function id(){return document.querySelector('#id').value.trim()}async function load(){try{const r=await fetch('/state?device='+encodeURIComponent(id()));const j=await r.json();document.querySelector('#state').textContent=JSON.stringify(j,null,2)}catch(e){document.querySelector('#state').textContent='Usluga nije dostupna.'}}async function send(action){document.querySelectorAll('#buttons button').forEach(b=>b.disabled=true);try{const r=await fetch('/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({device:id(),action})});const j=await r.json();document.querySelector('#msg').textContent=j.message||j.error;await load()}catch(e){document.querySelector('#msg').textContent='Slanje nije potvrđeno.'}finally{setTimeout(()=>document.querySelectorAll('#buttons button').forEach(b=>b.disabled=false),1500)}}setInterval(load,1500);load();</script></html>'''

def start_ui(school,host,port):
    lock=threading.RLock();events={}
    original_logger=school.logger
    def logger(event):
        original_logger(event)
        device=event.get('device_id')
        if device:
            with lock:events.setdefault(device,deque(maxlen=24)).append(event)
    school.logger=logger
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def reply(self,status,value,html=False):
            data=value.encode('utf-8') if html else json.dumps(value,ensure_ascii=False,allow_nan=False).encode('utf-8')
            self.send_response(status);self.send_header('Content-Type','text/html; charset=utf-8' if html else 'application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
        def do_GET(self):
            url=urlparse(self.path)
            if url.path=='/':return self.reply(200,UI_PAGE,True)
            if url.path!='/state':return self.reply(404,{'error':'Nepoznata adresa.'})
            device=parse_qs(url.query).get('device',[''])[0]
            with lock:
                try:
                    cfg=json.loads(school.config_path.read_text());known=device in cfg.get('devices',{})
                    out={'device':device,'profile':school.profile(device),'events':list(events.get(device,[]))} if known else {'error':'Nastavnik treba dodati taj ID prije rada.'}
                except Exception:out={'error':'Nastavnik treba provjeriti scenariji.json.'}
            self.reply(200,out)
        def do_POST(self):
            if self.path!='/action':return self.reply(404,{'error':'Nepoznata adresa.'})
            # Same-origin JSON only; the teaching LAN uses the original service's scope.
            origin=self.headers.get('Origin')
            if origin and urlparse(origin).netloc!=self.headers.get('Host'):return self.reply(403,{'error':'Nedopušten izvor.'})
            if self.headers.get('Content-Type','').split(';')[0]!='application/json':return self.reply(415,{'error':'Potreban je JSON.'})
            try:
                n=int(self.headers.get('Content-Length','0'))
                if not 0<n<=256:raise ValueError('Nevaljana duljina.')
                obj=json.loads(self.rfile.read(n));device=obj['device'];action=obj['action']
                if not isinstance(device,str) or action not in {'OPEN','CLOSE','AUTO','INVALID','DUPLICATE','DELAY','PREKID','NORMAL'}:raise ValueError('Nepoznata radnja.')
                with lock:
                    cfg=json.loads(school.config_path.read_text());devices=cfg.get('devices',{})
                    if device not in devices:raise ValueError('ID nije pripremljen za vježbu.')
                    p=dict(devices[device])
                    if p.get('scenario') == 'PREKID' and action not in {'PREKID','NORMAL'}:
                        raise ValueError('Najprije obnovi nadzor i pričekaj ONLINE.')
                    p['scenario']='NORMAL'
                    if action in {'PREKID','NORMAL','DELAY'}:
                        school.consumed_requests[device]=max(p.get('request_id',0),school.consumed_requests.get(device,0))
                    if action in {'OPEN','CLOSE','AUTO','INVALID','DUPLICATE'}:
                        p['request_id']=max(p.get('request_id',0),school.consumed_requests.get(device,0))+1
                        if action in {'OPEN','CLOSE','AUTO'}:p['command']=action
                        else:p['scenario']=action;p['invalid_kind']='ACTION'
                    else:
                        p['scenario']=action;p['delay_ms']=3000
                    devices[device]=p
                    tmp=school.config_path.with_suffix('.tmp');tmp.write_text(json.dumps(cfg,ensure_ascii=False,indent=2));tmp.replace(school.config_path)
                self.reply(200,{'message':'Postavka spremljena. Pričekaj novu razmjenu i ACK uređaja.','profile':p})
            except (ValueError,KeyError,TypeError,OSError) as e:self.reply(400,{'error':str(e)})
    http=ThreadingHTTPServer((host,port),Handler)
    threading.Thread(target=http.serve_forever,daemon=True).start()
    return http


async def main(host="0.0.0.0", port=8765, config_path=None, http_port=8084):
    config_path = config_path or Path(__file__).with_name("scenariji.json")
    school = SchoolServer(config_path)
    ui = start_ui(school,host,http_port)
    server = await asyncio.start_server(school.handle, host, port, limit=MAX_LINE)
    school.log("SERVER_READY", addresses=[str(s.getsockname()) for s in server.sockets],
               config=str(config_path), max_line_bytes=MAX_LINE)
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--http-port", type=int, default=8084)
    parser.add_argument("--config", type=Path,
                        default=Path(__file__).with_name("scenariji.json"))
    args = parser.parse_args()
    try:
        asyncio.run(main(args.host, args.port, args.config, args.http_port))
    except KeyboardInterrupt:
        print("Poslužitelj zaustavljen.")
